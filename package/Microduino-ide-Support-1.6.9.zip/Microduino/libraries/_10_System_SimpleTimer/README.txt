Visit this page for more information:
http://playground.arduino.cc/Code/SimpleTimer