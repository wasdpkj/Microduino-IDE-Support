#include <string.h>
#include <stdlib.h>

#include "wiring_constants.h"
#include "le501x-hal-adc.h"
#include "pins_arduino.h"


static uint8_t analogWidth = ADC_HW_BIT - ADCBITS_MIN;    // 12 bits
static uint8_t analogSamples = ADC_SAMPLETIME_NORMAL;  // 1/2/4/15 sample
static uint8_t analogClockDiv = ADC_CLOCK_DIV_NORMAL; // 8 div on 64Mhz

// Width of returned answer ()
static uint8_t analogReturnedWidth = 12;    //默认ADC分辨率

static uint8_t analog_reference = DEFAULT;
static uint8_t analogHwBits = ADC_HW_BIT;

static ADC_HandleTypeDef hadc;

static uint8_t sumReg(uint8_t _reg)
{
    if (_reg < 2 || _reg > 128)
        return 0;

    _reg &= 0xFE;
    uint8_t i = 0;
    while (i < 9)
    {
        if ((_reg >> i) < 1)
        {
            return (uint8_t)(i - 1);
        }
        i++;
    }

    return 0;
}

HAL_StatusTypeDef analogReference(uint8_t mode)
{
    // can't actually set the register here because the default setting
    // will connect AVCC and the AREF pin, which would cause a short if
    // there's something connected to AREF.
    analog_reference = mode;

    /* Process locked */
    __HAL_LOCK(&hadc);

    uint32_t _tmp_reg = 0U;
    switch (analog_reference)
    {
    case DEFAULT:
        // hadc.Init.Vref = ADC_VREF_VCC;
        _tmp_reg = FIELD_BUILD(ADC_VRPS, 1) | FIELD_BUILD(ADC_BP, 1) | FIELD_BUILD(ADC_VRBUFEN, 0) | FIELD_BUILD(ADC_VCMEN, 1) | FIELD_BUILD(ADC_VREFEN, 0);
        break;
    case EXTERNAL:
        // hadc.Init.Vref = ADC_VREF_EXPOWER;
        _tmp_reg = FIELD_BUILD(ADC_VRPS, 2) | FIELD_BUILD(ADC_BP, 1) | FIELD_BUILD(ADC_VRBUFEN, 0) | FIELD_BUILD(ADC_VCMEN, 1) | FIELD_BUILD(ADC_VREFEN, 0);
        break;
    case INTERNAL:
    default:
        // hadc.Init.Vref = ADC_VREF_INSIDE;
        _tmp_reg = FIELD_BUILD(ADC_VRPS, 4) | FIELD_BUILD(ADC_BP, 1) | FIELD_BUILD(ADC_VRBUFEN, 1) | FIELD_BUILD(ADC_VCMEN, 1) | FIELD_BUILD(ADC_VREFEN, 1);
        break;
    }

    MODIFY_REG(hadc.Instance->CCR, ADC_VRPS_MASK | ADC_BP_MASK | ADC_VRBUFEN_MASK | ADC_VCMEN_MASK | ADC_VREFEN_MASK, _tmp_reg);

    /* Process unlocked */
    __HAL_UNLOCK(&hadc);

    return HAL_OK;
}

void analogSetWidth(uint8_t bits)
{
    if (bits < ADCBITS_MIN)
    {
        bits = ADCBITS_MIN;
    }
    else if (bits > 12)
    {
        bits = 12;
    }

    if (bits % 2)
    {
        bits++;
    }

    // analogHwBits = bits;
    analogHwBits = ADC_HW_BIT;
    // analogReturnedWidth = bits;
    analogWidth = analogHwBits - ADCBITS_MIN;
}

void analogSetSamples(uint8_t samples)
{
    if (samples < 1 || samples > 15)
    {
        return;
    }

    if (samples == 1)
    {
        analogSamples = ADC_SAMPLETIME_1CYCLE;
    }
    else if (samples == 2)
    {
        analogSamples = ADC_SAMPLETIME_2CYCLES;
    }
    else if ((samples > 2) && (samples <= 4))
    {
        analogSamples = ADC_SAMPLETIME_4CYCLES;
    }
    else
    {
        analogSamples = ADC_SAMPLETIME_15CYCLES;
    }
}

void analogSetClockDiv(uint8_t clockDiv)
{
    if (clockDiv < 2 || clockDiv > 128)
    {
        return;
    }
    analogClockDiv = sumReg(clockDiv);
}

static bool initialized = false;
static bool firstBoot = true;
void analogDeinit()
{
    HAL_ADC_DeInit(&hadc);
    initialized = false;
    firstBoot = true;
}

HAL_StatusTypeDef analogInit()
{
    if (initialized)
    {
        return HAL_STATE_ERROR;
    }

    analogSetWidth(analogWidth + ADCBITS_MIN); // in bits

    hadc.Instance = LSADC;
    hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
    hadc.Init.ScanConvMode = ADC_SCAN_DISABLE;
    hadc.Init.NbrOfConversion = 1;
    hadc.Init.DiscontinuousConvMode = DISABLE;
    hadc.Init.NbrOfDiscConversion = 1;
    hadc.Init.ContinuousConvMode = DISABLE;
    hadc.Init.TrigType = ADC_REGULAR_SOFTWARE_TRIGT; /* !<Trig of conversion start done by which event */
    // hadc.Init.Vref = ADC_VREF_VCC;                    /*ADC_VREF_VCC/ADC_VREF_EXPOWER/ADC_VREF_INSIDE*/
    hadc.Init.AdcDriveType = BINBUF_DIRECT_DRIVE_ADC; /*BINBUF_DIRECT_DRIVE_ADC/INRES_ONETHIRD_EINBUF_DRIVE_ADC*/
    hadc.Init.AdcCkDiv = (uint32_t)analogClockDiv;

    switch (analog_reference)
    {
    case DEFAULT:
        hadc.Init.Vref = ADC_VREF_VCC;
        break;
    case EXTERNAL:
        hadc.Init.Vref = ADC_VREF_EXPOWER;
        break;
    case INTERNAL:
    default:
        hadc.Init.Vref = ADC_VREF_INSIDE;
        break;
    }

    if (HAL_ADC_Init(&hadc) == HAL_OK)
    {
        /* Process locked */
        __HAL_LOCK(&hadc);

        REG_FIELD_WR(hadc.Instance->CR2, ADC_BATADJ, 0x01);     //[0 = 1/8] [1 = 1/4] [2 = 3/8] [3 = 1/2]

        // REG_FIELD_WR(hadc.Instance->CR1, ADC_RES, (analogHwBits - ADCBITS_MIN) / 2);
        // REG_FIELD_WR(hadc.Instance->CR1, ADC_RES, 0x01);    //8bit
        // REG_FIELD_WR(hadc.Instance->CR1, ADC_RES, 0x02);    //10bit
        // REG_FIELD_WR(hadc.Instance->CR1, ADC_RES, 0x03);    //12bit

        /* Process unlocked */
        __HAL_UNLOCK(&hadc);
    }

    initialized = true;

    return HAL_OK;
}

uint16_t vbatRead()
{
    uint16_t _vbat, _batVol;
    uint8_t _saveAref = analog_reference;
    uint8_t _saveResolution = analogReturnedWidth;

    if (firstBoot)
    {
        firstBoot = false;
        analogRead(VBAT);
    }

    if(_saveAref != INTERNAL)
    {
        analogReference(INTERNAL);
    }
    if(_saveResolution != ADC_HW_BIT)
    {
        analogReadResolution(ADC_HW_BIT);
    }

    _vbat = analogRead(VBAT);

    if(_saveAref != INTERNAL)
    {
        analogReference(_saveAref);
    }
    if(_saveResolution != ADC_HW_BIT)
    {
        analogReadResolution(_saveResolution);
    }

    // BATADJ = 1/4, VREF = 1.4V
    // _batVol = (100 * (4 * (_vbat + 1)) / 4096) * (1.4);
    _batVol = (140 * (_vbat + 1)) / 1024;   
    // LOG_RAW("_vbat: %d, batVol: %d\r\n", _vbat, batVol);

    return (uint16_t)_batVol;
}

bool adcDeAttachPin(uint8_t pin)
{
    int8_t channel = analogPinToChannel(pin);
    if (channel < 0)
    {
        return false; // not adc pin
    }

    if (channel < 9)
    {
        gpio_ana_deinit(pin);
    }

    analogDeinit();

    return true;
}

bool adcAttachPin(uint8_t pin)
{
    int8_t channel = analogPinToChannel(pin);
    if (channel < 0)
    {
        return false; // not adc pin
    }

    if (channel < 9)
    {
        pinmux_ana_func1_init(pin);
    }

    analogInit();

    ADC_ChannelConfTypeDef sConfig = {0};
    sConfig.Channel = (uint32_t)channel;
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = (uint32_t)analogSamples;

    if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
    {
        return false;
    }

    return true;
}

bool adcStart(uint8_t pin)
{
    int8_t channel = analogPinToChannel(pin);
    if (channel < 0)
    {
        return false; // not adc pin
    }

    if (HAL_ADC_Start(&hadc) != HAL_OK)
    {
        return false;
    }

    if (HAL_ADC_PollForConversion(&hadc, 20) != HAL_OK) /*!< timeout 20ms*/
    {
        return false;
    }

    return true;
}

bool adcBusy(uint8_t pin)
{
    int8_t channel = analogPinToChannel(pin);
    if (channel < 0)
    {
        return false; // not adc pin
    }

    return (HAL_ADC_GetState(&hadc) & HAL_ADC_STATE_REG_BUSY);
}

uint32_t adcEnd(uint8_t pin)
{
    int8_t channel = analogPinToChannel(pin);
    if (channel < 0)
    {
        return 0; // not adc pin
    }

    uint16_t value = (uint16_t)HAL_ADC_GetValue(&hadc); // Return adc value

    // Shift result if necessary
    uint8_t from = analogWidth + ADCBITS_MIN;
    if (from == analogReturnedWidth)
    {
        return value;
    }
    if (from > analogReturnedWidth)
    {
        return value >> (from - analogReturnedWidth);
    }
    return value << (analogReturnedWidth - from);
}

uint16_t analogRead(uint8_t pin)
{
    if (!adcAttachPin(pin) || !adcStart(pin))
    {
        return 0;
    }

    return (uint16_t)adcEnd(pin);
}

void analogReadResolution(uint8_t bits)
{
    if (!bits || bits > 16)
    {
        return;
    }

    analogSetWidth(bits);       // hadware from 6 / 8 / 10 / 12
    analogReturnedWidth = bits; // software from 1 to 16
}
