#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>

#include "wiring_private.h"
#include "HardwareSerial.h"


#undef LOG_TAG
#define LOG_TAG "HWSERIAL"


#if !defined(NO_GLOBAL_INSTANCES) && !defined(NO_GLOBAL_SERIAL)
UART_HandleTypeDef UART0_Config;
HardwareSerial Serial(0);
#define SERIAL0_HANDLE          UART3
#if defined(HAVE_HWSERIAL1)
UART_HandleTypeDef UART1_Config;
HardwareSerial Serial1(1);
#define SERIAL1_HANDLE  UART1
#endif
#if defined(HAVE_HWSERIAL2)
UART_HandleTypeDef UART2_Config;
HardwareSerial Serial2(2);
#define SERIAL2_HANDLE  UART2
#endif
#if defined(HAVE_HWSERIAL3)
UART_HandleTypeDef UART3_Config;
HardwareSerial Serial3(3, PIN_RXD3, PIN_TXD3);
#define SERIAL2_HANDLE  UART3
#endif
#endif


hwSerial_global_t hwSerial_data[MAX_NBR_OF_HWSERIAL];

// SerialEvent functions are weak, so when the user doesn't define them,
// the linker just sets their address to 0 (which is checked below).
// The Serialx_available is just a wrapper around Serialx.available(),
// but we can refer to it weakly so we don't pull in the entire
// HardwareSerial instance if the user doesn't also refer to it.
  void serialEvent() __attribute__((weak));
  bool Serial0_available() __attribute__((weak));

#if defined(HAVE_HWSERIAL1)
  void serialEvent1() __attribute__((weak));
  bool Serial1_available() __attribute__((weak));
#endif

#if defined(HAVE_HWSERIAL2)
  void serialEvent2() __attribute__((weak));
  bool Serial2_available() __attribute__((weak));
#endif

#if defined(HAVE_HWSERIAL3)
  void serialEvent3() __attribute__((weak));
  bool Serial3_available() __attribute__((weak));
#endif


void serialEventRun(void)
{
  if (Serial0_available && serialEvent && Serial0_available()) serialEvent();
#if defined(HAVE_HWSERIAL1)
  if (Serial1_available && serialEvent1 && Serial1_available()) serialEvent1();
#endif
#if defined(HAVE_HWSERIAL2)
  if (Serial2_available && serialEvent2 && Serial2_available()) serialEvent2();
#endif
#if defined(HAVE_HWSERIAL3)
  if (Serial3_available && serialEvent3 && Serial3_available()) serialEvent3();
#endif
}

uint16_t transfor_baud(unsigned long baud)
{
    return UART_BUADRATE_ENUM_GEN(baud);
}

static void serial_pinmux_init(reg_uart_t * _handle, uint8_t txd, uint8_t rxd)
{
    if(_handle == UART1)
    {
        pinmux_uart1_init(txd, rxd);    
    }
#if defined(UART2)
    else if(_handle == UART2)
    {
        pinmux_uart2_init(txd, rxd);    
    }
#endif    
#if defined(UART3)
    else if(_handle == UART3)
    {
        pinmux_uart3_init(txd, rxd);    
    }
#endif    
#if defined(UART4)
    else if(_handle == UART4)
    {
        pinmux_uart4_init(txd, rxd);    
    }
#endif    
}


static void serial_pinmux_deinit(reg_uart_t * _handle)
{
    if(_handle == UART1)
    {
        pinmux_uart1_deinit();    
    }
#if defined(UART2)
    else if(_handle == UART2)
    {
        pinmux_uart2_deinit();    
    }
#endif    
#if defined(UART3)
    else if(_handle == UART3)
    {
        pinmux_uart3_deinit();    
    }
#endif    
#if defined(UART4)
    else if(_handle == UART4)
    {
        pinmux_uart4_deinit();    
    }
#endif    
}


static void _rx_complete_irq(UART_HandleTypeDef *huart, hwSerial_global_t* _serial)
{
    unsigned char c = _serial->_rx_byte;

    rx_buffer_index_t i = (unsigned int)(_serial->_rx_buffer_head + 1) % SERIAL_RX_BUFFER_SIZE;

    // if we should be storing the received character into the location
    // just before the tail (meaning that the head would advance to the
    // current location of the tail), we're about to overflow the buffer
    // and so we don't write the character or advance the head.
    if (i != _serial->_rx_buffer_tail)
    {
        _serial->_rx_buffer[_serial->_rx_buffer_head] = c;
        _serial->_rx_buffer_head = i;
    }

    HAL_UART_Receive_IT(huart, &_serial->_rx_byte, 1);
}


static uint16_t uartAvailableForWrite(UART_HandleTypeDef* huart)
{
    return huart->Tx_Env.Interrupt.XferCount;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &UART0_Config)
    {
        _rx_complete_irq(huart, &hwSerial_data[0]);
    }
#if defined(HAVE_HWSERIAL1)    
    else if (huart == &UART1_Config)
    {
        _rx_complete_irq(huart, &hwSerial_data[1]);
    }
#endif
#if defined(HAVE_HWSERIAL2)    
    else if (huart == &UART2_Config)
    {
        _rx_complete_irq(huart, &hwSerial_data[2]);
    }
#endif
#if defined(HAVE_HWSERIAL3)
    else if (huart == &UART3_Config)
    {
        _rx_complete_irq(huart, &hwSerial_data[3]);
    }
#endif
}


void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &UART0_Config)
    {
        hwSerial_data[0]._tx_busy = 0;
    }
#if defined(HAVE_HWSERIAL1)    
    else if (huart == &UART1_Config)
    {
        hwSerial_data[1]._tx_busy = 0;
    }
#endif
#if defined(HAVE_HWSERIAL2)
    else if (huart == &UART2_Config)
    {
        hwSerial_data[2]._tx_busy = 0;
    }
#endif
#if defined(HAVE_HWSERIAL3)
    else if (huart == &UART3_Config)
    {
        hwSerial_data[3]._tx_busy = 0;
    }
#endif
}


HardwareSerial::HardwareSerial(int uart_nr) : _uart_nr(uart_nr), _rx_pin(-1), _tx_pin(-1), _uart(NULL) {}

HardwareSerial::~HardwareSerial()
{
    end();
}

void HardwareSerial::begin(unsigned long baud, uint32_t config, int8_t rxpin, int8_t txpin, bool invert, unsigned long timeout_ms)
{   
    _rx_pin = rxpin;
    _tx_pin = txpin;
    if (_uart_nr == 0)
    {
        _uart = &UART0_Config;
        _uart->UARTX = SERIAL0_HANDLE;
        if(_rx_pin == -1 && _tx_pin == -1)
        {
            _rx_pin = PIN_RXD0;
            _tx_pin = PIN_TXD0;
        }
    }
#if defined(HAVE_HWSERIAL1)
    else if (_uart_nr == 1)
    {
        _uart = &UART1_Config;
        _uart->UARTX = SERIAL1_HANDLE;
        if(_rx_pin == -1 && _tx_pin == -1)
        {
            _rx_pin = PIN_RXD1;
            _tx_pin = PIN_TXD1;
        }
    }
#endif
#if defined(HAVE_HWSERIAL2)
    else if (_uart_nr == 2)
    {
        _uart = &UART2_Config;
        _uart->UARTX = SERIAL2_HANDLE;
        if(_rx_pin == -1 && _tx_pin == -1)
        {
            _rx_pin = PIN_RXD2;
            _tx_pin = PIN_TXD2;
        }
    }
#endif
#if defined(HAVE_HWSERIAL3)
    else if (_uart_nr == 3)
    {
        _uart = &UART3_Config;
        _uart->UARTX = SERIAL3_HANDLE;
        if(_rx_pin == -1 && _tx_pin == -1)
        {
            _rx_pin = PIN_RXD3;
            _tx_pin = PIN_TXD3;
        }
    }
#endif
    else
    {
        LOG_RAW("Serial number is invalid!\r\n");
        return;
    }


    serial_pinmux_init(_uart->UARTX, (uint8_t)_tx_pin, (uint8_t)_rx_pin);

    _serialTimeout = timeout_ms;

    hwSerial_data[_uart_nr]._tx_it_en = false;
    hwSerial_data[_uart_nr]._tx_busy = false;

    _uart->Init.BaudRate = (app_uart_baudrate_t)transfor_baud(baud);

    _uart->Init.WordLength = 0x03 & (config >> 5);
    _uart->Init.StopBits = 0x01 & (config >> 4);
    _uart->Init.Parity = 0x03 & (config >> 2);

    if (invert)
    {
        _uart->Init.MSBEN = 1;
    }
    else
    {
        _uart->Init.MSBEN = 0;
    }
    _uart->Init.HwFlowCtl = 0;

    HAL_UART_Init(_uart);
    HAL_UART_Receive_IT(_uart, &hwSerial_data[_uart_nr]._rx_byte, 1);

    _written = false;
}

void HardwareSerial::txInterruptOn()
{
    hwSerial_data[_uart_nr]._tx_it_en = true;
}

void HardwareSerial::txInterruptOff()
{
    hwSerial_data[_uart_nr]._tx_it_en = false;
}


void HardwareSerial::end()
{
    // wait for transmission of outgoing data
    flush();

    hwSerial_data[_uart_nr]._rx_buffer_head = hwSerial_data[_uart_nr]._rx_buffer_tail;

    serial_pinmux_deinit(_uart->UARTX);
    _uart = 0;
}

int HardwareSerial::available(void)
{
    return ((unsigned int)(SERIAL_RX_BUFFER_SIZE + hwSerial_data[_uart_nr]._rx_buffer_head - hwSerial_data[_uart_nr]._rx_buffer_tail)) % SERIAL_RX_BUFFER_SIZE;
}

int HardwareSerial::availableForWrite(void)
{
    if(!hwSerial_data[_uart_nr]._tx_it_en)
    {
        return -1;
    }

    if(hwSerial_data[_uart_nr]._tx_busy)
    {
        return uartAvailableForWrite(_uart);
    }

    return 0;
}

int HardwareSerial::peek(void)
{
    if (hwSerial_data[_uart_nr]._rx_buffer_head == hwSerial_data[_uart_nr]._rx_buffer_tail)
    {
        return -1;
    }
    else
    {
        return hwSerial_data[_uart_nr]._rx_buffer[hwSerial_data[_uart_nr]._rx_buffer_tail];
    }
}

int HardwareSerial::read(void)
{
    // if the head isn't ahead of the tail, we don't have any characters
    if (hwSerial_data[_uart_nr]._rx_buffer_head == hwSerial_data[_uart_nr]._rx_buffer_tail)
    {
        return -1;
    }
    else
    {
        unsigned char c = hwSerial_data[_uart_nr]._rx_buffer[hwSerial_data[_uart_nr]._rx_buffer_tail];
        hwSerial_data[_uart_nr]._rx_buffer_tail = (rx_buffer_index_t)(hwSerial_data[_uart_nr]._rx_buffer_tail + 1) % SERIAL_RX_BUFFER_SIZE;
        return c;
    }
}

void HardwareSerial::flush()
{
    // If we have never written a byte, no need to flush. This special
    // case is needed since there is no way to force the TXC (transmit
    // complete) bit to 1 during initialization
    if (!_written)
        return;
}


void HardwareSerial::setTxTimeout(uint32_t _timeout)
{
    _serialTimeout = _timeout;
}

size_t HardwareSerial::write(uint8_t c)
{
    _written = true;

    if(!hwSerial_data[_uart_nr]._tx_it_en)
    {
        HAL_UART_Transmit(_uart, (uint8_t*)&c, 1, _serialTimeout);
    }
    else
    {
        hwSerial_data[_uart_nr]._tx_busy = true;
        HAL_UART_Transmit_IT(_uart, (uint8_t*)&c, 1);
    }

    return 1;
}

size_t HardwareSerial::write(const uint8_t *buffer, size_t size)
{
    _written = true;

    uint8_t *data = (uint8_t*)buffer;

    if(!hwSerial_data[_uart_nr]._tx_it_en)
    {
        HAL_UART_Transmit(_uart, data, size, _serialTimeout);
    }
    else
    {
        hwSerial_data[_uart_nr]._tx_busy = true;
        HAL_UART_Transmit_IT(_uart, data, size);
    }

    return size;
}

size_t HardwareSerial::write(uint8_t *buffer, size_t size)
{
    _written = true;

    if(!hwSerial_data[_uart_nr]._tx_it_en)
    {
        HAL_UART_Transmit(_uart, buffer, size, _serialTimeout);
    }
    else
    {
        hwSerial_data[_uart_nr]._tx_busy = true;
        HAL_UART_Transmit_IT(_uart, buffer, size);
    }

    return size;
}

HardwareSerial::operator bool() const
{
    return true;
}
