/*
  wiring_private.h - Internal header file.
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2005-2006 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA
*/

#ifndef WiringPrivate_h
#define WiringPrivate_h


// #include "field_manipulate.h"
#include "platform.h"
#include "prf_diss.h"
#include "le501x.h"
#include "platform.h"
#include "cpu.h"
#include "systick.h"
#include "sleep.h"
#if  defined(LE501X_BLE) || defined(LE501X_MESH)
  #include "ls_ble.h"
  #include "builtin_timer.h"
#endif
#include "co_math.h"
#include "log.h"
#include "ls_dbg.h"
#include "SEGGER_RTT.h"
#include "HAL_def.h"

// #include "ls_soc_pinmux.h"
// #include "ls_soc_gpio.h"
// #include "reg_gpio.h"


#ifdef __cplusplus
extern "C"{
#endif


#if  defined(LE501X_BLE) || defined(LE501X_MESH)
void ble_sched();
#endif


#define EXTERNAL_INT_0    0
#define EXTERNAL_INT_1    1
#define EXTERNAL_INT_2    2 
#define EXTERNAL_INT_3    3
#define EXTERNAL_INT_4    4
#define EXTERNAL_INT_5    5
#define EXTERNAL_INT_6    6
#define EXTERNAL_INT_7    7
#define EXTERNAL_INT_8    8
#define EXTERNAL_INT_9    9
#define EXTERNAL_INT_10   10
#define EXTERNAL_INT_11   11
#define EXTERNAL_INT_12   12
#define EXTERNAL_INT_13   13
#define EXTERNAL_INT_14   14
#define EXTERNAL_INT_15   15


#ifdef __cplusplus
}; // extern "C"
#endif

#endif
