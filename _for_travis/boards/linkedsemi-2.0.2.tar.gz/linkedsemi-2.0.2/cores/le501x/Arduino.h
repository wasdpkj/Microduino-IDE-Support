#ifndef ARDUINO_H_
#define ARDUINO_H_

#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "pgmspace.h"

#include "wiring_private.h"


#include "le501x-hal-gpio.h"
#include "le501x-hal-adc.h"
#include "le501x-hal-pwm.h"


#include "binary.h"

#ifdef __cplusplus
  extern "C" {
#endif


#include "wiring_constants.h"


#define clockCyclesPerMicrosecond() ( SDK_HCLK_MHZ )
#define clockCyclesToMicroseconds(a) ( (a) / clockCyclesPerMicrosecond() )
#define microsecondsToClockCycles(a) ( (a) * clockCyclesPerMicrosecond() )


long map(long, long, long, long, long);


void init(void);
void initVariant(void);

void yield(void);

//----------main------------
void setup(void);
void loop(void);


#ifdef __cplusplus
} // extern "C"
#endif


#ifdef __cplusplus
#include "WCharacter.h"
#include "WString.h"
#include "HardwareSerial.h"

// WMath prototypes
#include "WMath.h"
#endif


//----------Interrupt------------
#include "WInterrupts.h"
//----------Delay------------
#include "delay.h"

#include "pins_arduino.h"

void tone(uint8_t _pin, unsigned int frequency, unsigned long duration = 0);
void noTone(uint8_t _pin);
void help_freq(unsigned int *_frequency, uint16_t *number);

#endif
