/*
 HardwareSerial.h - Hardware serial library for Wiring
 Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

 Modified 28 September 2010 by Mark Sproul
 Modified 14 August 2012 by Alarus
 Modified 3 December 2013 by Matthijs Kooijman
 Modified 2023 by Panda (wasdpkj@hotmail.com) - LE501X Support
*/

#ifndef HardwareSerial_h
#define HardwareSerial_h

#include <inttypes.h>

#include "Stream.h"
#include "pins_arduino.h"
#include "ls_hal_uart.h"


#if !defined(SERIAL_RX_BUFFER_SIZE)
#define SERIAL_RX_BUFFER_SIZE 128
#endif

#if  (SERIAL_RX_BUFFER_SIZE>256)
typedef uint16_t rx_buffer_index_t;
#else
typedef uint8_t rx_buffer_index_t;
#endif


// Define config for Serial.begin(baud, config);
#define SERIAL_5N1 0x00
#define SERIAL_6N1 0x20
#define SERIAL_7N1 0x40
#define SERIAL_8N1 0x60
#define SERIAL_5N2 0x10
#define SERIAL_6N2 0x30
#define SERIAL_7N2 0x50
#define SERIAL_8N2 0x70

#define SERIAL_5E1 0x0C
#define SERIAL_6E1 0x2C
#define SERIAL_7E1 0x4C
#define SERIAL_8E1 0x6C
#define SERIAL_5E2 0x1C
#define SERIAL_6E2 0x3C
#define SERIAL_7E2 0x5C
#define SERIAL_8E2 0x7C

#define SERIAL_5O1 0x04
#define SERIAL_6O1 0x24
#define SERIAL_7O1 0x44
#define SERIAL_8O1 0x64
#define SERIAL_5O2 0x14
#define SERIAL_6O2 0x34
#define SERIAL_7O2 0x54
#define SERIAL_8O2 0x74

typedef struct  
{
    volatile rx_buffer_index_t _rx_buffer_head;
    volatile rx_buffer_index_t _rx_buffer_tail;

    // Don't put any members after these buffers, since only the first
    // 32 bytes of this struct can be accessed quickly using the ldd
    // instruction.
    unsigned char _rx_buffer[SERIAL_RX_BUFFER_SIZE]; 
    uint8_t _rx_byte;

    bool _tx_it_en;
    bool _tx_busy;
} hwSerial_global_t;




class HardwareSerial: public Stream
{
public:
    HardwareSerial(int uart_nr);
    ~HardwareSerial();

    void begin(unsigned long baud, uint32_t config=SERIAL_8N1, int8_t rxPin=-1, int8_t txPin=-1, bool invert=false, unsigned long timeout_ms = 500UL);
    void end();
    // void updateBaudRate(unsigned long baud);
    int available(void);
    int availableForWrite(void);
    int peek(void);
    int read(void);
    void txInterruptOn();
    void txInterruptOff();
    void setTxTimeout(uint32_t _timeout);
    void flush(void);
    size_t write(uint8_t);
    size_t write(const uint8_t *buffer, size_t size);
    size_t write(uint8_t *buffer, size_t size);

    inline size_t write(const char * s)
    {
        return write((uint8_t*) s, strlen(s));
    }
    inline size_t write(unsigned long n)
    {
        return write((uint8_t) n);
    }
    inline size_t write(long n)
    {
        return write((uint8_t) n);
    }
    inline size_t write(unsigned int n)
    {
        return write((uint8_t) n);
    }
    inline size_t write(int n)
    {
        return write((uint8_t) n);
    }
    
    operator bool() const;

protected:
    int _uart_nr;
    int8_t _rx_pin, _tx_pin;
    UART_HandleTypeDef* _uart;
    uint32_t _serialTimeout;

    // Has any byte been written to the UART since begin()
    bool _written;

};


#if defined(UART1)
#define HAVE_HWSERIAL0
#endif
#if defined(UART2)
#define HAVE_HWSERIAL1
#endif
#if defined(UART3)
#define HAVE_HWSERIAL2
#endif
#if defined(UART4)
#define HAVE_HWSERIAL3
#endif

#if !defined(NO_GLOBAL_INSTANCES) && !defined(NO_GLOBAL_SERIAL)
extern HardwareSerial Serial;

#if defined(HAVE_HWSERIAL1)
extern HardwareSerial Serial1;
#endif

#if defined(HAVE_HWSERIAL2)
extern HardwareSerial Serial2;
#endif

#if defined(HAVE_HWSERIAL3)
extern HardwareSerial Serial3;
#endif

#endif

#if defined(HAVE_HWSERIAL0)
#if defined(HAVE_HWSERIAL1)
#if defined(HAVE_HWSERIAL2)
#if defined(HAVE_HWSERIAL3)
#define MAX_NBR_OF_HWSERIAL     4
#else
#define MAX_NBR_OF_HWSERIAL     3
#endif  //HAVE_HWSERIAL3
#else
#define MAX_NBR_OF_HWSERIAL     2
#endif  //HAVE_HWSERIAL2
#else
#define MAX_NBR_OF_HWSERIAL     1
#endif  //HAVE_HWSERIAL1
#else
#define MAX_NBR_OF_HWSERIAL     0
#endif  //HAVE_HWSERIAL0

extern void serialEventRun(void) __attribute__((weak));

#endif
