#include "Arduino.h"
#include "le501x-hal-timer.h"

#define _useSoftTimer
// #define _useHardTimer

#if defined(_useSoftTimer)

#define MAX_TONE (1)

static boolean tone_pin_isActive[MAX_TONE] = {false /*, false, false */};
static uint8_t tone_pins[MAX_TONE] = {255 /*, 255, 255 */};

typedef struct
{
    bool waitout;
    unsigned int freq;
    unsigned int freqcount;
    unsigned int ticks;
    int32_t duration;
} tone_swtimer_t;
static tone_swtimer_t tone_swtimer[MAX_TONE];

static SW_TIM_HandleTypeDef toneSoftTimHandle = {
    .init{
        .period = -1,
        .timer = -1,
    },
    .channel = SOFTTIMER_CHANNEL_TONE,
    .period = 0,
    .periodCalc = 0,
    .number = -1};

#define SOFT_PWM_PERIOD_US (toneSoftTimHandle.period)
#define MAX_FREQ (1000000 / (SOFT_PWM_PERIOD_US * 2))
#define MIN_FREQ (20)

#elif defined(_useHardTimer)

#endif

#if defined(_useSoftTimer)

static boolean isTimerActive(void)
{
    // returns true if any servo is active on this timer
    for (uint8_t channel = 0; channel < MAX_TONE; channel++)
    {
        if (tone_pin_isActive[channel] == true)
            return true;
    }
    return false;
}

static inline void handle_interrupts(void)
{
    for (uint8_t i = 0; i < MAX_TONE; i++)
    {
        if (tone_pin_isActive[i])
        {
            tone_swtimer[i].ticks += SOFT_PWM_PERIOD_US;
            if(tone_swtimer[i].duration > 0)
            {
                tone_swtimer[i].duration -= SOFT_PWM_PERIOD_US;
                if(0 == tone_swtimer[i].duration)
                {
                    tone_swtimer[i].duration = -1;
                }
            }
            if(tone_swtimer[i].duration < 0)
            {
                noTone(tone_pins[i]);
            }
            else if (tone_swtimer[i].ticks >= tone_swtimer[i].freqcount)
            {
                if(0 == tone_swtimer[i].waitout)
                {
                    fastClrPin(tone_pins[i]);
                    tone_swtimer[i].waitout = 1;
                }
                else
                {
                    fastSetPin(tone_pins[i]);
                    tone_swtimer[i].waitout = 0;
                }
                tone_swtimer[i].ticks = 0;
            }
        }
    }
}

static void initISR(void)
{
    toneSoftTimHandle.init.period = -1;
    toneSoftTimHandle.init.timer = -1;

    toneSoftTimHandle.channel = SOFTTIMER_CHANNEL_TONE;

    if (toneSoftTimHandle.init.period <= 0)
    {
        toneSoftTimHandle.period = DEFAULT_SWTIM_PERIOD;
    }
    else
    {
        toneSoftTimHandle.period = toneSoftTimHandle.init.period;
    }

    toneSoftTimHandle.periodCalc = 0;
    toneSoftTimHandle.number = -1;
    softTimerAttachInterrupt(&toneSoftTimHandle, handle_interrupts);
}

static void finISR(void)
{
    // disable use of the given timer
    softTimerDetachInterrupt(&toneSoftTimHandle);
}

static int8_t toneBegin(uint8_t _pin)
{
    for (int i = 0; i < MAX_TONE; i++)
    {
        if (tone_pins[i] == 255)
        {
            tone_pins[i] = _pin;
            pinMode(tone_pins[i], OUTPUT);
            return 1;
        }
    }
    return -1;
}

#elif defined(_useHardTimer)

#endif

void tone(uint8_t _pin, unsigned int frequency, unsigned long duration)
{

    if (0 == frequency)
    {
        return;
    }
    else
    {
        if (isTimerActive() == false)
        {
            for (int i = 0; i < MAX_TONE; i++)
            {
                if (tone_pins[i] == _pin)
                {
                    tone_pin_isActive[i] = true;
                    tone_swtimer[i].ticks = 0;
                }
            }
            initISR();
        }

        if (frequency > (unsigned int)MAX_FREQ)
        {
            frequency = (unsigned int)MAX_FREQ;
        }
        else if (frequency < MIN_FREQ)
        {
            frequency = MIN_FREQ;
        }
    }

#if defined(_useSoftTimer)
    toneBegin(_pin);
    for (int i = 0; i < MAX_TONE; i++)
    {
        if (tone_pins[i] == _pin)
        {
            if(tone_swtimer[i].freq != frequency)
            {
                tone_swtimer[i].freqcount = (unsigned int)(1000000.0 / (frequency * 2));
                tone_swtimer[i].duration = duration * 1000;
                tone_swtimer[i].freq = frequency;
            }
        }
    }
#elif defined(_useHardTimer)
#endif
}

void noTone(uint8_t _pin)
{
#if defined(_useSoftTimer)
    for (int i = 0; i < MAX_TONE; i++)
    {
        if (tone_pins[i] == _pin)
        {
            tone_pin_isActive[i] = false;
            tone_swtimer[i].ticks = 0;
            tone_swtimer[i].freqcount = 0;
            tone_swtimer[i].freq = 0;
            tone_swtimer[i].waitout = 0;
            fastClrPin(tone_pins[i]);
        }
    }

    if (isTimerActive() == false)
    {
        finISR();
    }
#elif defined(_useHardTimer)
#endif
}

void help_freq(unsigned int *_frequency, uint16_t *number)
{
    static int _freq = 0, _freqC = 0;
    uint16_t index = 0;

    if (isTimerActive() == false)
    {
        initISR();
    }
    int max_count = 1000000 / MIN_FREQ / (DEFAULT_SWTIM_PERIOD * 2);
    for (unsigned int i = max_count; i >= 1; i--)
    {
        _freq = (unsigned int)(1000000.0 / (i * DEFAULT_SWTIM_PERIOD * 2));
        if (_freqC != _freq)
        {
            _frequency[index] = _freq;
            index++;
            _freqC = _freq;
        }
    }
    *number = index;
    if (isTimerActive() == false)
    {
        finISR();
    }
}
