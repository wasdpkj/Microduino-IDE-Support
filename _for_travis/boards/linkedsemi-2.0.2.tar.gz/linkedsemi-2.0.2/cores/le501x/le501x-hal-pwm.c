#include "wiring_constants.h"
#include "le501x-hal-pwm.h"
#include "le501x-hal-gpio.h"
#include "le501x-hal-timer.h"



#if defined(LE501X)
#define PIN_SET(pin) (fastSetPin(pin))
#define PIN_CLR(pin) (fastClrPin(pin))

#if (SOFT_HALPWM_PERIOD_US < SOFTTIM_PERIOD)
#error "SOFT_HALPWM_PERIOD_US < SOFTTIM_PERIOD"
#endif
#endif

static SW_TIM_HandleTypeDef softTimHandle;


static volatile uint8_t _isr_softcount = 0xff;

typedef struct
{
  // hardware I/O port and pin for this channel
  int8_t pin;

  uint8_t pwmvalue;
  uint8_t checkval;
} softHALPWMChannel;

static softHALPWMChannel _softpwm_channels[SOFT_HALPWM_MAXCHANNELS];

// Here is the meat and gravy
static void hal_SoftPWM_Timer_Interrupt(void)
{
  uint8_t i;

  if(++_isr_softcount == 0)
  {
    // set all channels high - let's start again
    // and accept new checkvals
    for (i = 0; i < SOFT_HALPWM_MAXCHANNELS; i++)
    {
     
      _softpwm_channels[i].checkval = _softpwm_channels[i].pwmvalue;

      // now set the pin high (if not 0)
      if (_softpwm_channels[i].checkval > 0)  // don't set if checkval == 0
      {
        PIN_SET(_softpwm_channels[i].pin);
      }

    }
  }

  for (i = 0; i < SOFT_HALPWM_MAXCHANNELS; i++)
  {
    if (_softpwm_channels[i].pin >= 0)  // if it's a valid pin
    {
      if (_softpwm_channels[i].checkval == _isr_softcount)  // if we have hit the width
      {
        // turn off the channel
        PIN_CLR(_softpwm_channels[i].pin);
      }
    }
  }


}


static void SoftPWMInit(void)
{
  softTimHandle.init.period = -1;      
  softTimHandle.init.timer = -1;      
  softTimHandle.channel = SOFTTIMER_CHANNEL_HALPWM;  
  softTimHandle.period = SOFT_HALPWM_PERIOD_US;      
  softTimHandle.periodCalc = 0;      
  softTimHandle.number = -1;      
  softTimerAttachInterrupt(&softTimHandle, hal_SoftPWM_Timer_Interrupt); 

  for (uint8_t i = 0; i < SOFT_HALPWM_MAXCHANNELS; i++)
  {
    _softpwm_channels[i].pin = -1;
  }

}


static void SoftPWMSet(int8_t pin, uint8_t value, uint8_t hardset)
{
  int8_t firstfree = -1;  // first free index
  uint8_t i;

  if (hardset)
  {
    _isr_softcount = 0xff;
  }

  // If the pin isn't already set, add it
  for (i = 0; i < SOFT_HALPWM_MAXCHANNELS; i++)
  {
    if ((pin < 0 && _softpwm_channels[i].pin >= 0) ||  // ALL pins
       (pin >= 0 && _softpwm_channels[i].pin == pin))  // individual pin
    {
      // set the pin (and exit, if individual pin)
      _softpwm_channels[i].pwmvalue = value;

      if (pin >= 0) // we've set the individual pin
        return;
    }

    // get the first free pin if available
    if (firstfree < 0 && _softpwm_channels[i].pin < 0)
      firstfree = i;
  }

  if (pin >= 0 && firstfree >= 0)
  {
    // we have a free pin we can use
    _softpwm_channels[firstfree].pin = pin;
    _softpwm_channels[firstfree].pwmvalue = value;
    // _softpwm_channels[firstfree].checkval = 0;
    
    // now prepare the pin for output
    // turn it off to start (no glitch)
    digitalWrite(pin, LOW);
    pinMode(pin, OUTPUT);
  }
}


static void SoftPWMEnd(int8_t pin)
{
  uint8_t i;

  for (i = 0; i < SOFT_HALPWM_MAXCHANNELS; i++)
  {
    if ((pin < 0 && _softpwm_channels[i].pin >= 0) ||  // ALL pins
       (pin >= 0 && _softpwm_channels[i].pin == pin))  // individual pin
    {
      // now disable the pin (put it into INPUT mode)
      digitalWrite(_softpwm_channels[i].pin, 1);
      pinMode(_softpwm_channels[i].pin, INPUT);

      // remove the pin
      _softpwm_channels[i].pin = -1;
    }
  }
}


static void SoftPWMDeinit(void)
{
  softTimerDetachInterrupt(&softTimHandle); 
}


//------------user------------
static bool initialized = false;

static bool softPwmIsActive[MAX_GPIO_NUM] = {0};
static boolean isPwmActive(void)
{
  // returns true if any softPwm is active
  for (uint8_t i = 0; i < MAX_GPIO_NUM; i++) {
    if (softPwmIsActive[i] == true)
      return true;
  }
  return false;
}


bool softPwmInit()
{
    if (initialized)
    {
        return false;
    }
    
    SoftPWMInit();
    for(uint8_t i = 0;i < MAX_GPIO_NUM;i++)
    {
        softPwmIsActive[i] = false;
    }
    initialized = true;

    return true;
}


bool softPwmDeinit()
{
    if(!initialized)
    {
        return false;
    }

    for(uint8_t i = 0;i < MAX_GPIO_NUM;i++)
    {
        if(softPwmIsActive[i])
        {
            softPwmDetachPin(i);
        }
        softPwmIsActive[i] = false;
    }
    SoftPWMDeinit();

    initialized = false;

    return true;
}


bool softPwmDetachPin(uint8_t pin)
{
    if(!initialized || (pin >= MAX_GPIO_NUM))
    {
        return false;
    }

    SoftPWMEnd(pin);
    softPwmIsActive[pin] = false;

    if(isPwmActive() == false)
    {
        softPwmDeinit();
    }

    return true;
}


void analogWrite(uint8_t pin, uint8_t val)
{
    if(pin >= MAX_GPIO_NUM)
    {
        return;
    }

    if (!initialized)
    {
        softPwmInit();
    }

    softPwmIsActive[pin] = true;

    SoftPWMSet(pin, val, 0);
}
