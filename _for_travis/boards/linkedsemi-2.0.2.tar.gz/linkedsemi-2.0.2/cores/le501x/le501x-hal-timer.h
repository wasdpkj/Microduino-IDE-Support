#ifndef MAIN_LE501X_HAL_TIMER_H_
#define MAIN_LE501X_HAL_TIMER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "ls_hal_timer.h"

/* ---------------hardware timer--------------- */
void timerAttachInterrupt(TIM_HandleTypeDef *timer, void (*fn)(void));
void timerDetachInterrupt(TIM_HandleTypeDef *timer);


/* ---------------hardware pwm--------------- */
void pwmInit(uint8_t _timer, uint32_t _period);
void pwmDeinit(void);
void pwmAttachPin(uint8_t _pin, uint8_t _channel);
void pwmDetachPin(uint8_t _channel);
void pwmUpdata(uint8_t _channel, uint32_t _pulse);
uint8_t pwmMaxNbr(void);

#define HW_PWM_CHANNEL        4
#define HARDTIM_PRESCALER     (SDK_HCLK_MHZ-1)
#define HARDTIM_PERIOD        (16)          /* Period Value 32us */

/* ---------------software timer--------------- */
enum{
  TIMER_0 = 0,
  TIMER_1,
  TIMER_2,
  TIMER_3,
  MAX_TIMER,
};
#define DEFAULT_SWTIM_SOURCE        TIMER_0

#define SOFTTIM_PRESCALER           (SDK_HCLK_MHZ-1)
#if (SDK_HCLK_MHZ == 64)
#define DEFAULT_SWTIM_PERIOD        (32)          /* Period Value 32us */
#elif (SDK_HCLK_MHZ == 32)
#define DEFAULT_SWTIM_PERIOD        (48)          /* Period Value 48us */
#else
#define DEFAULT_SWTIM_PERIOD        (64)          /* Period Value 64us */
#endif

#define SOFTTIMER_MAXCHANNELS     8

#define SOFTTIMER_CHANNEL_SERVO   0
#define SOFTTIMER_CHANNEL_HALPWM  1
#define SOFTTIMER_CHANNEL_PWM     2
#define SOFTTIMER_CHANNEL_TONE    3
#define SOFTTIMER_CHANNEL_IR      4

/**
 * @brief  SW TIM Time Base Handle Structure definition
 */
typedef struct
{
  int32_t period;     /*!< Locking object           */
  int8_t timer;       /*!< Locking object           */
}USER_TIM_InitDef;

typedef struct
{
  USER_TIM_InitDef init;
  int8_t channel;           /*!< Active channel           */
  int32_t period;           /*!< Locking object           */
  int32_t periodCalc;       /*!< Locking object           */
  int8_t number;            /*!< Locking object           */
} SW_TIM_HandleTypeDef;


void softTimerInit(SW_TIM_HandleTypeDef *_handle);
void softTimerDeinit();

void softTimerAttachInterrupt(SW_TIM_HandleTypeDef *swtimer, void (*fn)(void));
void softTimerDetachInterrupt(SW_TIM_HandleTypeDef *swtimer);

#ifdef __cplusplus
}
#endif

#endif /* MAIN_LE501X_HAL_TIMER_H_ */
