#ifndef MAIN_LE501X_HAL_PWM_H_
#define MAIN_LE501X_HAL_PWM_H_

#ifdef __cplusplus
extern "C" {
#endif


#define SOFT_HALPWM_MAXCHANNELS       8
#define SOFT_HALPWM_PERIOD_US         64          /* ≈ 60Hz */



bool softPwmInit(void);

bool softPwmDeinit(void);

bool softPwmDetachPin(uint8_t pin);

/*
 * \brief Set the resolution of analogWrite parameters. Default is 8 bits (range from 0 to 255).
 */
void analogWrite(uint8_t pin, uint8_t val);


#ifdef __cplusplus
};
#endif

#endif /* MAIN_LE501X_HAL_ADC_H_ */
