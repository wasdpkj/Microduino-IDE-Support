#ifndef CALC_ACC_H_
#define CALC_ACC_H_

#ifdef __cplusplus
extern "C" {
#endif

void calc_acc_init(void);

#ifdef __cplusplus
}
#endif

#endif
