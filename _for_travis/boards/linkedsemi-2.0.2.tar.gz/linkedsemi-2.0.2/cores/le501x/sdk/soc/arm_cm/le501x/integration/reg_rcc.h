#ifndef REG_RCC_H_
#define REG_RCC_H_
#include "reg_rcc_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RCC ((reg_rcc_t *)0x40021000)

#ifdef __cplusplus
}
#endif

#endif
