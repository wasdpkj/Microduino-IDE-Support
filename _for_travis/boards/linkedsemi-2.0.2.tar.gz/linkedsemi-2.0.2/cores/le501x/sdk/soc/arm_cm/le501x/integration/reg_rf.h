#ifndef REG_RF_H_
#define REG_RF_H_
#include "reg_rf_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RF ((reg_rf_t *)0x40007400)

#ifdef __cplusplus
}
#endif

#endif
