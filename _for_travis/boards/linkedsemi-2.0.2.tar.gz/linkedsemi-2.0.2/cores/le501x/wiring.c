/*
  wiring.c - Partial implementation of the Wiring API for the ATmega8.
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2005-2006 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA
*/

#include "wiring_private.h"

#if defined(LE501X_BLE) || defined(LE501X_MESH)
static void __ble_null_app(enum dev_evt_type type, union dev_evt_u *evt){};
#endif

void init()
{
	// this needs to be called before setup() or some functions won't
	// work there
#if  defined(LE501X_BLE)
  #if defined(LE501X_MESH) || defined(LE501X_MCU)
  #error "Only one system mode can be set"
  #else
  sys_init_app();   
  ble_init();
  dev_manager_register_callback(__ble_null_app);
  // LOG_RAW("LE501X_BLE\r\n");
  #endif
#elif defined(LE501X_MESH)
  #if defined(LE501X_MCU)
  #error "Only one system mode can be set"
  #else
  sys_init_app();   
  ble_init();
  dev_manager_register_callback(__ble_null_app);
  // LOG_RAW("LE501X_MESH\r\n");
  #endif
#elif  defined(LE501X_MCU)
  sys_init_none();   
  // LOG_RAW("LE501X_MCU\r\n");
#else
#error "#error "Please set the system mode: LE501X_MCU / LE501X_BLE / LE501X_MESH""
#endif

}
