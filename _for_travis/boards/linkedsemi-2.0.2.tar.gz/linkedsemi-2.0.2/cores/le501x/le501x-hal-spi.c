#include "le501x-hal-spi.h"

// --------------------spi----------------------
#define SPI_I2S_TX_FIFO_DEPTH 16
#define SPI_I2S_TX_FIFO_NOT_FULL(__HANDLE__) (REG_FIELD_RD((__HANDLE__)->Instance->SR, SPI_SR_TXFLV) < SPI_I2S_TX_FIFO_DEPTH)
#define SPI_I2S_RX_FIFO_NOT_EMPTY(__HANDLE__) (REG_FIELD_RD((__HANDLE__)->Instance->SR, SPI_SR_RXFLV) > 0)

// --------------------ssi----------------------
#define SSI_TX_FIFO_DEPTH 4
#define SSI_RX_FIFO_DEPTH 4

// --------------------spi----------------------
static void spi_tx_load_data_8bit(SPI_HandleTypeDef *hspi)
{
    *((uint8_t *)&hspi->Instance->DR) = *((uint8_t *)hspi->Tx_Env.Interrupt.pBuffPtr);
    hspi->Tx_Env.Interrupt.pBuffPtr += sizeof(uint8_t);
    hspi->Tx_Env.Interrupt.Count--;
}

static void load_tx_dummy_data(SPI_HandleTypeDef *hspi)
{
    *((uint8_t *)&hspi->Instance->DR) = 0;
    hspi->Tx_Env.Interrupt.Count--;
}


HAL_StatusTypeDef HAL_SPI_Transmit_FAST(SPI_HandleTypeDef *hspi, uint8_t *pTxData, uint16_t Size)
{   
    CLEAR_BIT(hspi->Instance->CR1, SPI_CR1_RXONLY_MASK);

    hspi->Tx_Env.Interrupt.pBuffPtr = (uint8_t *)pTxData;
    hspi->Tx_Env.Interrupt.Count = Size;

    hspi->Tx_Env.Interrupt.transfer_Fun = hspi->Tx_Env.Interrupt.pBuffPtr ? spi_tx_load_data_8bit: load_tx_dummy_data;

    SET_BIT(hspi->Instance->CR1, SPI_CR1_SPE_MASK);
    {
        uint8_t i = hspi->Tx_Env.Interrupt.Count;
        while(i--)
        {
            hspi->Tx_Env.Interrupt.transfer_Fun(hspi);
        }
    }
    
    while ((hspi->Tx_Env.Interrupt.Count > 0U) || (hspi->Rx_Env.Interrupt.Count > 0U))
    {
        if (SPI_I2S_TX_FIFO_NOT_FULL(hspi) && (hspi->Tx_Env.Interrupt.Count > 0U))
        {
            hspi->Tx_Env.Interrupt.transfer_Fun(hspi);
        }
    }

    while (REG_FIELD_RD(hspi->Instance->SR,SPI_SR_BSY) == 1U);
    CLEAR_BIT(hspi->Instance->CR1, SPI_CR1_SPE_MASK);

    return HAL_OK;
}

// --------------------ssi----------------------
static inline void ssi_ser_cfg(SSI_HandleTypeDef *hssi)
{
    hssi->REG->SER = hssi->Hardware_CS_Mask ? hssi->Hardware_CS_Mask : 0xff;
}

HAL_StatusTypeDef HAL_SSI_Transmit_FAST(SSI_HandleTypeDef *hssi,void *Data,uint16_t Count)
{
    hssi->Tx_Env.Interrupt.Data = Data;
    hssi->Tx_Env.Interrupt.Count = Count;

    void *ctrl = &hssi->Init.ctrl;
    uint32_t ctrlr0 = *(uint32_t *)ctrl;
    MODIFY_REG(ctrlr0,SSI_FRF_MASK|SSI_TMOD_MASK,Motorola_SPI<<SSI_FRF_POS|Transmit_Only<<SSI_TMOD_POS);
    hssi->REG->CTRLR0 = ctrlr0;

    hssi->REG->DMACR = 0;
    hssi->REG->TXFTLR = SSI_TX_FIFO_DEPTH/2;
    //hssi->REG->RXFTLR = hssi->Rx_Env.Interrupt.Count > SSI_RX_FIFO_DEPTH ? 0 : hssi->Rx_Env.Interrupt.Count - 1;
    hssi->REG->RXFTLR = 0; //rx full -> rx overflow issue workaround
    hssi->REG->IMR = FIELD_BUILD(SSI_MSTIM,1) | FIELD_BUILD(SSI_RXFIM,false)|
        FIELD_BUILD(SSI_RXOIM,1) | FIELD_BUILD(SSI_RXUIM,1) | FIELD_BUILD(SSI_TXOIM,1) |
        FIELD_BUILD(SSI_TXEIM,false);
    hssi->REG->SSIENR = SSI_Enabled;

    while(REG_FIELD_RD(hssi->REG->SR,SSI_TFNF)&&hssi->Tx_Env.Interrupt.Count)
    {
        hssi->DR_REG[0] = *(uint8_t *)hssi->Tx_Env.Interrupt.Data;
        hssi->Tx_Env.Interrupt.Data += 1;

        --hssi->Tx_Env.Interrupt.Count;
    }

    ssi_ser_cfg(hssi);

    while(hssi->Tx_Env.Interrupt.Count)
    {
        while(REG_FIELD_RD(hssi->REG->SR,SSI_TFNF)&&hssi->Tx_Env.Interrupt.Count)
        {
            hssi->DR_REG[0] = *(uint8_t *)hssi->Tx_Env.Interrupt.Data;
            hssi->Tx_Env.Interrupt.Data += 1;
            
            --hssi->Tx_Env.Interrupt.Count;
        }
    }

    while(REG_FIELD_RD(hssi->REG->SR,SSI_BUSY) == SSI_Busy);
    hssi->REG->SSIENR = SSI_Disabled;
    hssi->REG->SER = 0;

    return HAL_OK;
}
