#include <stdint.h>
#include <string.h>
#include "cpu.h"
#include "ls_hal_timer.h"
#include "ls_dbg.h"
#include "ls_soc_pinmux.h"
#include "platform.h"
#include "field_manipulate.h"
#include "ls_hal_dmac.h"
#include "ls_hal_flash.h"
#include "audio_hw.h"
#include "api_implemented_by_user.h"
#include "user_audio_api.h"
#include "le501x.h"
#include "log.h"

static struct audio_hw_config* user_audio_hw_config_ptr;
static TIM_HandleTypeDef TimHandle;
static uint32_t tim_dma_config;
static uint32_t pwm_remainder;
static volatile uint8_t stop_audio_flag;

static void (*user_audio_play_cplt_cb)(void*);
static void *user_cb_param;

static uint8_t audio_volume = AUDIO_PCM_VOLUME_1_2;
uint8_t api_getVolume(void)
{
    return audio_volume;
}

void api_setVolume(uint8_t _val)
{
    audio_volume = _val;
}


void audio_set_stop_flag(void)
{
    stop_audio_flag = 1;
}

void audio_handle_pcm(void *dst_pcm_buf1, void *dst_pcm_buf2, const pcm_src_item_size_t *raw_pcm_buf)
{
    uint8_t volume = api_getVolume();
    pcm_buf_item_size_t *dst_buf_ptr1 = (pcm_buf_item_size_t*)dst_pcm_buf1;
#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL  
    pcm_buf_item_size_t *dst_buf_ptr2 = (pcm_buf_item_size_t*)dst_pcm_buf2;
    for (uint16_t i = 0; i < get_pcm_buf_size()/USER_AUDIO_RESOLUTION; i++)
    {
    #if USER_AUDIO_PCM_FORMAT == AUDIO_PCM_UNSIGNED
        if (raw_pcm_buf[i] & UNSIGNED_MSB)
        {
            dst_buf_ptr1[i] = (pcm_buf_item_size_t)((raw_pcm_buf[i] - UNSIGNED_MSB) >> (USER_AUDIO_RESOLUTION*8 - RESOLUTION_DEFAULT)) >> volume;
            dst_buf_ptr2[i] = 0;
        }
        else
        {
            dst_buf_ptr1[i] = 0;
            dst_buf_ptr2[i] = (pcm_buf_item_size_t)((UNSIGNED_MSB - raw_pcm_buf[i]) >> (USER_AUDIO_RESOLUTION*8 - RESOLUTION_DEFAULT)) >> volume;
        }
    #else // unsigned pcm format
        if (raw_pcm_buf[i] < 0) // negative value
        {
            dst_buf_ptr1[i] = (pcm_buf_item_size_t)((-raw_pcm_buf[i]) >> (USER_AUDIO_RESOLUTION*8 - RESOLUTION_DEFAULT)) >> volume;
            dst_buf_ptr2[i] = 0;
        }
        else
        {
            dst_buf_ptr1[i] = 0;
            dst_buf_ptr2[i] = (pcm_buf_item_size_t)(raw_pcm_buf[i] >> (USER_AUDIO_RESOLUTION*8 - RESOLUTION_DEFAULT)) >> volume;
        }
    #endif
        
    }
#else
    for (uint16_t i = 0; i < get_pcm_buf_size()/USER_AUDIO_RESOLUTION; i++)
    {
    #if USER_AUDIO_PCM_FORMAT == AUDIO_PCM_UNSIGNED
        dst_buf_ptr1[i] = (pcm_buf_item_size_t)(raw_pcm_buf[i] >> (USER_AUDIO_RESOLUTION*8 - RESOLUTION_DEFAULT)) >> volume;
    #else
        dst_buf_ptr1[i] = (pcm_buf_item_size_t)((raw_pcm_buf[i] + UNSIGNED_MSB) >> (USER_AUDIO_RESOLUTION*8 - RESOLUTION_DEFAULT)) >> volume;
    #endif
    }
#endif
}

static void dma_channel_config_update(DMA_Controller_HandleTypeDef *hdma, uint8_t ch_idx, bool alt, uint32_t *ctrl_data)
{
    struct DMA_Channel_Config cfg;
    HAL_DMA_Channel_Config_Get(hdma, ch_idx, alt, &cfg);
    cfg.ctrl_data = *(struct ctrl_data_config *)ctrl_data;
    HAL_DMA_Channel_Config_Set(hdma, ch_idx, alt, &cfg);
}

static void dma_ch1_finish_cb(void *hdma, uint32_t param, uint8_t ch_idx, bool current_alt)
{
    if (stop_audio_flag > 0)
    {
        stop_audio_flag++;
        dma_channel_config_update(hdma, ch_idx, !current_alt, &tim_dma_config);
        if (3 == stop_audio_flag)
        {
            extern void audio_stop(void);
            audio_stop();
            stop_audio_flag = 0;
            if (user_audio_play_cplt_cb != NULL)
            {
                user_audio_play_cplt_cb(user_cb_param);
            }
        }
    }
    else
    {
        dma_channel_config_update(hdma, ch_idx, !current_alt, &tim_dma_config);
        audio_prepare_next_half(current_alt);
    }
}
#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL  
static void dma_ch2_finish_cb(void *hdma, uint32_t param, uint8_t ch_idx, bool current_alt)
{
    dma_channel_config_update(hdma, ch_idx, !current_alt, &tim_dma_config);
}
#endif
static void XIP_BANNED_FUNC(update_timer_repetition_counter, bool increase)
{
    reg_timer_t* timer = user_audio_hw_config_ptr->timer_inst;
    if (increase)
    {
        timer->REP = TIMER_REPETITION_COUNTER_INIT;
    }
    else
    {
        timer->REP = TIMER_REPETITION_COUNTER_INIT - 1;
    }
}
static void XIP_BANNED_FUNC(timer_handler_ram, void)
{
    reg_timer_t* timer = user_audio_hw_config_ptr->timer_inst;
    if ((timer->RIF & TIM_FLAG_CC1) != 0 && (timer->IVS & TIM_IT_CC1) != 0)
    {
        timer->ICR |= TIM_IT_CC1;
        pwm_remainder += TIMER_REPETITION_COUNTER_REMAINDER;
        if (pwm_remainder >= USER_AUDIO_SAMPLERATE * (1 << RESOLUTION_ACTUAL))
        {
            pwm_remainder -= USER_AUDIO_SAMPLERATE * (1 << RESOLUTION_ACTUAL);
            update_timer_repetition_counter(true);
        }
        else
        {
            update_timer_repetition_counter(false);
        }
    }
    if ((timer->RIF & TIM_FLAG_CC2) != 0 && (timer->IVS & TIM_IT_CC2) != 0)
    {
        timer->ICR |= TIM_IT_CC2;
    }
}
static void timer_config(void)
{
    TIM_OC_InitTypeDef sConfig = {0};
    TimHandle.Instance = user_audio_hw_config_ptr->timer_inst;
    TimHandle.Init.Prescaler = 0;
    TimHandle.Init.Period = 1 << RESOLUTION_ACTUAL;
    TimHandle.Init.ClockDivision = 0;
    TimHandle.Init.CounterMode = TIM_COUNTERMODE_UP;
    TimHandle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    TimHandle.Init.RepetitionCounter = TIMER_REPETITION_COUNTER_INIT - 1;
    pwm_remainder = TIMER_REPETITION_COUNTER_REMAINDER;
    HAL_TIM_Init(&TimHandle);
    arm_cm_set_int_isr(user_audio_hw_config_ptr->timer_irq, timer_handler_ram);
    sConfig.OCMode = TIM_OCMODE_PWM1;
    sConfig.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfig.OCFastMode = TIM_OCFAST_DISABLE;
    sConfig.Pulse = 0;
    HAL_TIM_PWM_ConfigChannel(&TimHandle, &sConfig, TIM_CHANNEL_1);
#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL     
    HAL_TIM_PWM_ConfigChannel(&TimHandle, &sConfig, TIM_CHANNEL_2);
#endif    
    REG_FIELD_WR(user_audio_hw_config_ptr->timer_inst->DMAEN, TIMER_DMAEN_UDE, 1);
}
static void dmac_channel_config(struct ctrl_data_config *ctrl, uint8_t channel)
{
#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL  
    uint32_t dummy_array[] = {(uint32_t)dma_ch1_finish_cb,  (uint32_t)dma_ch2_finish_cb};
    uint8_t *buf_array[] = {get_pcm_buf0(), get_pcm_buf1(), get_pcm_buf2(), get_pcm_buf3()};
#else
    uint32_t dummy_array[] = {(uint32_t)dma_ch1_finish_cb};
    uint8_t *buf_array[] = {get_pcm_buf0(), get_pcm_buf1()};
#endif
    uint32_t ccr_array[] = {(uint32_t)&user_audio_hw_config_ptr->timer_inst->CCR1, (uint32_t)&user_audio_hw_config_ptr->timer_inst->CCR2};
    struct DMA_Channel_Config prim;
    prim.src_data_end_ptr = (uint32_t)&buf_array[(channel - 1)*2][get_single_buf_size() - 1];
    prim.dst_data_end_ptr = ccr_array[channel - 1];
    prim.ctrl_data = *ctrl;
    prim.dummy = dummy_array[channel - 1];
    struct DMA_Channel_Config alt;
    alt.src_data_end_ptr = (uint32_t)&buf_array[(channel - 1)*2 + 1][get_single_buf_size() - 1];
    alt.dst_data_end_ptr = ccr_array[channel - 1];
    alt.ctrl_data = *ctrl;
    alt.dummy = dummy_array[channel - 1];
    HAL_DMA_Channel_Config_Set(user_audio_hw_config_ptr->dmac_inst_ptr, channel, false, &prim);
    HAL_DMA_Channel_Config_Set(user_audio_hw_config_ptr->dmac_inst_ptr, channel, true, &alt);
}
static void dmac_config(void)
{
    uint8_t dma_size = RESOLUTION_ACTUAL > 8 ? DMA_SIZE_HALFWORD : DMA_SIZE_BYTE;
    struct ctrl_data_config *ctrl = (struct ctrl_data_config *)&tim_dma_config;
    ctrl->cycle_ctrl = DMA_Cycle_PingPong;
    ctrl->next_useburst = 0;
    ctrl->n_minus_1 = get_single_buf_size()/(RESOLUTION_ACTUAL > 8 ? 2: 1) - 1 ;
    ctrl->R_power = 0;
    ctrl->src_prot_ctrl = 0;
    ctrl->dst_prot_ctrl = 0;
    ctrl->src_size = dma_size;
    ctrl->src_inc = RESOLUTION_ACTUAL > 8 ? DMA_INC_HALFWORD : DMA_INC_BYTE;
    ctrl->dst_size = dma_size;
    ctrl->dst_inc = DMA_INC_NONE;
    dmac_channel_config(ctrl, user_audio_hw_config_ptr->dma_channel1);
#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL  
    dmac_channel_config(ctrl, user_audio_hw_config_ptr->dma_channel2);
#endif
}
void audio_hw_init(struct audio_hw_config* config)
{
    user_audio_hw_config_ptr = config;
    timer_config();
    dmac_config();
}

void audio_hw_deinit(void)
{
    pinmux_gptimc1_ch1_deinit();
#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL     
    pinmux_gptimc1_ch2_deinit();
#endif    
    HAL_TIM_DeInit(&TimHandle);
}

void audio_start(uint32_t audio_base, uint32_t audio_length, void (*play_cplt_cb)(void *), void *param)
{
    memset(get_pcm_buf0(), 0, get_single_buf_size());
    memset(get_pcm_buf1(), 0, get_single_buf_size());
#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL  
    memset(get_pcm_buf2(), 0, get_single_buf_size());
    memset(get_pcm_buf3(), 0, get_single_buf_size());
#endif
    // HAL_TIM_PWM_Start_IT(&TimHandle, TIM_CHANNEL_1);
    // HAL_DMA_Channel_Start_IT(user_audio_hw_config_ptr->dmac_inst_ptr, user_audio_hw_config_ptr->dma_channel1, user_audio_hw_config_ptr->handshake, 0);

    dmac_config();
    extern void TIM_CCxChannelCmd(reg_timer_t *TIMx, uint32_t Channel, uint32_t ChannelState);

    __HAL_TIM_ENABLE_IT(&TimHandle, TIM_IT_CC1);
    TIM_CCxChannelCmd((&TimHandle)->Instance, TIM_CHANNEL_1, TIM_CCx_ENABLE);
    __HAL_TIM_MOE_ENABLE(&TimHandle);

    DMA_Controller_HandleTypeDef *hdma = user_audio_hw_config_ptr->dmac_inst_ptr;
    uint8_t ch_idx = user_audio_hw_config_ptr->dma_channel1;
    uint8_t handshake = user_audio_hw_config_ptr->handshake;

    hdma->channel_param[ch_idx] = 0;
    MODIFY_REG(hdma->Instance->CHSEL[ch_idx/4],0xff<< 8 * (ch_idx % 4),handshake<< 8 * (ch_idx%4));
    hdma->Instance->DONEICF = 1<<ch_idx;
    uint32_t cpu_stat = enter_critical();
    hdma->Instance->DONEIEF |= 1<<ch_idx;
    exit_critical(cpu_stat);

#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL  
    // __HAL_TIM_ENABLE_IT(&TimHandle, TIM_IT_CC2);
    TIM_CCxChannelCmd((&TimHandle)->Instance, TIM_CHANNEL_2, TIM_CCx_ENABLE);
    // __HAL_TIM_MOE_ENABLE(&TimHandle);

    ch_idx = user_audio_hw_config_ptr->dma_channel2;

    hdma->channel_param[ch_idx] = 0;
    MODIFY_REG(hdma->Instance->CHSEL[ch_idx/4],0xff<< 8 * (ch_idx % 4),handshake<< 8 * (ch_idx%4));
    hdma->Instance->DONEICF = 1<<ch_idx;
    cpu_stat = enter_critical();
    hdma->Instance->DONEIEF |= 1<<ch_idx;
    exit_critical(cpu_stat);
#endif

    // Enable pwm & dmac ASAP
    cpu_stat = enter_critical();
    __HAL_TIM_ENABLE(&TimHandle);
    hdma->Instance->ENSET = ((1<< user_audio_hw_config_ptr->dma_channel1)
#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL 
    | (1 << user_audio_hw_config_ptr->dma_channel2)
#endif
    );
    exit_critical(cpu_stat);

    audio_play_init(audio_base, audio_length);
    stop_audio_flag = 0;
    user_audio_play_cplt_cb = play_cplt_cb;
    user_cb_param = param;
}

void audio_stop(void)
{
    user_audio_hw_config_ptr->timer_inst->CCR1 = 0;
    HAL_TIM_PWM_Stop_IT(&TimHandle, TIM_CHANNEL_1);
    HAL_DMA_Channel_Abort(user_audio_hw_config_ptr->dmac_inst_ptr, user_audio_hw_config_ptr->dma_channel1);
#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL     
    user_audio_hw_config_ptr->timer_inst->CCR2 = 0;
    HAL_TIM_PWM_Stop(&TimHandle, TIM_CHANNEL_2);
    HAL_DMA_Channel_Abort(user_audio_hw_config_ptr->dmac_inst_ptr, user_audio_hw_config_ptr->dma_channel2);
#endif    
}
