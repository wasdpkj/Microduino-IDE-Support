#include "utility\audio_definition.h"
#ifndef USER_AUDIO_CONFIG_FOR_LIB_H_
#define USER_AUDIO_CONFIG_FOR_LIB_H_

#ifdef __cplusplus
  extern "C" {
#endif

struct user_audio_config_t
{
    uint32_t base;
    uint32_t length;
};

#ifndef USER_AUDIO_FORMAT
#define USER_AUDIO_FORMAT       AUDIO_PCM
#endif

#ifndef USER_AUDIO_OUTPUT_MODE
#define USER_AUDIO_OUTPUT_MODE  AUDIO_OUTPUT_MODE_DIFFERENTIAL
#endif

#ifndef USER_AUDIO_SAMPLERATE
#define USER_AUDIO_SAMPLERATE   AUDIO_SAMPLERATE_8K
#endif

#ifndef USER_AUDIO_RESOLUTION
#define USER_AUDIO_RESOLUTION   AUDIO_RESOLUTION_8BIT
#endif

#ifndef USER_AUDIO_PCM_FORMAT
#define USER_AUDIO_PCM_FORMAT   AUDIO_PCM_UNSIGNED
#endif


#define RESOLUTION_DEFAULT 8
#if RESOLUTION_DEFAULT > (USER_AUDIO_RESOLUTION*8)
#error "The resolution is not supported!!!"
#endif


#ifdef __cplusplus
};
#endif

#endif
