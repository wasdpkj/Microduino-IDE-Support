/*
  TwoWire.cpp - TWI/I2C library for Arduino & Wiring
  Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

  Modified 2012 by Todd Krein (todd@krein.org) to implement repeated starts
  Modified 2023 by Panda (wasdpkj@hotmail.com) - LE501X Support
 */

extern "C" {
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
}

#include "Arduino.h"
#include "Wire.h"

#undef  LOG_TAG
#define LOG_TAG "WIRE"

I2C_HandleTypeDef I2C1_Config;
static I2C_HandleTypeDef I2C2_Config;
#ifdef I2C3_BASE_ADDR
static I2C_HandleTypeDef I2C3_Config;
#endif

#ifndef I2C_CLOCK
#define I2C_CLOCK   (SDK_PCLK_MHZ*1000000)
#endif

static uint32_t transfor_i2cFreq(uint32_t _in)
{
    if(_in > 1000000)
    {
        return I2C_SPEED_MAX;
    }
    else if(_in > 400000)
    {
        return I2C_SPEED_FAST_ULTRA_1M;
    }
    else if(_in > 100000)
    {
        return I2C_SPEED_FAST_400K;
    }

    return I2C_SPEED_NORMAL_100K;
}

static size_t i2cFreq;
size_t i2cGetFrequency(I2C_HandleTypeDef *hi2c)
{
    return i2cFreq;
}

HAL_StatusTypeDef i2cSetFrequency(I2C_HandleTypeDef *hi2c, uint32_t _clock)
{
    uint32_t freq,SCLH,SCLL,sdadel,scldel;
    uint32_t pclk1;

    /* Check the I2C handle allocation */
    if (hi2c == NULL)
    {
        return HAL_ERROR;
    }
    
    if(_clock <= 2000)
    {
        _clock = 2000;
    }
    else if(_clock > 1000000)
    {
        _clock = 1000000;
    }
    i2cFreq = _clock;


    /* Process Locked */
    __HAL_LOCK(hi2c);

    /* Disable the selected I2C peripheral */
    __HAL_I2C_DISABLE(hi2c);


    hi2c->Init.ClockSpeed = transfor_i2cFreq(_clock);

    /* Check the parameters */
    // LS_ASSERT(IS_I2C_CLOCK_SPEED(hi2c->Init.ClockSpeed));

    if (hi2c->State == HAL_I2C_STATE_RESET)
    {
        /* Allocate lock resource and initialize it */
        hi2c->Lock = HAL_UNLOCKED;
    }

    // hi2c->State = HAL_I2C_STATE_BUSY;

    /* Calculate frequency value */
    if(i2cFreq < I2C_MIN_FREQ)
        pclk1 = I2C_CLOCK>>5;
    else
    {
        pclk1 = I2C_CLOCK;
    }

    freq = I2C_FREQRANGE(pclk1, i2cFreq);
    SCLL = freq/2;
    SCLH = freq - SCLL;              //If it's not divisible,The remainder is added to SCLH
    sdadel = SCLH/4;
    scldel = SCLH/4;

    /*---------------------------- I2Cx TIMINGR Configuration ----------------------*/
    /* Configure I2Cx: Frequency range */
    if(i2cFreq < I2C_MIN_FREQ)
    {
        MODIFY_REG(hi2c->Instance->TIMINGR, I2C_TIMINGR_PRESC_MASK, 32u<<I2C_TIMINGR_PRESC_POS); 
    }
    else
    {
        CLEAR_BIT(hi2c->Instance->TIMINGR, I2C_TIMINGR_PRESC_MASK);
    }

    MODIFY_REG(hi2c->Instance->TIMINGR, (I2C_TIMINGR_SCLH_MASK | I2C_TIMINGR_SCLL_MASK), \
               (SCLH<<I2C_TIMINGR_SCLH_POS | \
                SCLL<<I2C_TIMINGR_SCLL_POS | \
                sdadel<<I2C_TIMINGR_SDADEL_POS | \
                scldel<<I2C_TIMINGR_SCLDEL_POS));
      
    /* Enable the selected I2C peripheral */
    __HAL_I2C_ENABLE(hi2c);

    /* Enable the selected I2C peripheral */
    __HAL_UNLOCK(hi2c);

    return HAL_OK;
}


TwoWire::TwoWire(uint8_t bus_num)
    :num(bus_num & 1)
    ,sda(-1)
    ,scl(-1)
    ,_i2c(NULL)
    ,rxIndex(0)
    ,rxLength(0)
    ,rxQueued(0)
    ,txIndex(0)
    ,txLength(0)
    ,txAddress(0)
    ,txQueued(0)
    ,transmitting(0)
    ,last_error(I2C_ERROR_OK)
    ,_timeOutMillis(20)
{}

TwoWire::~TwoWire()
{
    flush();
    if(_i2c) {
        HAL_I2C_DeInit(_i2c);

   if(num == 0) {
        /* Configure the GPIO AF */
	    pinmux_iic1_deinit();
    }
    else if(num == 1){
        /* Configure the GPIO AF */
	    pinmux_iic2_deinit();
    }
#ifdef I2C3_BASE_ADDR
    else if(num == 2){
        /* Configure the GPIO AF */
	    pinmux_iic3_deinit();
    }
#endif
        // i2cRelease(_i2c);
        _i2c=NULL;
    }
}

bool TwoWire::begin(int sdaPin, int sclPin, uint32_t frequency)
{
    if(sdaPin < 0) { // default param passed
        if(num == 0) {
            if(sda==-1) {
                sdaPin = SDA;    //use Default Pin
            } else {
                sdaPin = sda;    // reuse prior pin
            }
        } else {
            if(sda==-1) {
                LOG_RAW("no Default SDA Pin for Second Peripheral\r\n");
                return false; //no Default pin for Second Peripheral
            } else {
                sdaPin = sda;    // reuse prior pin
            }
        }
    }

    if(sclPin < 0) { // default param passed
        if(num == 0) {
            if(scl == -1) {
                sclPin = SCL;    // use Default pin
            } else {
                sclPin = scl;    // reuse prior pin
            }
        } else {
            if(scl == -1) {
                LOG_RAW("no Default SCL Pin for Second Peripheral\r\n");
                return false; //no Default pin for Second Peripheral
            } else {
                sclPin = scl;    // reuse prior pin
            }
        }
    }

    sda = sdaPin;
    scl = sclPin;

    if(frequency <= 1000)
    {
        frequency = 100000;
    }
    else if(frequency > 1000000)
    {
        frequency = 1000000;
    }

    if(num == 0) {
        /* Configure the GPIO AF */
	    pinmux_iic1_init(scl, sda);
        _i2c = &I2C1_Config;
        _i2c->Instance             = I2C1;
    }
    else if(num == 1){
        /* Configure the GPIO AF */
	     pinmux_iic2_init(scl, sda);
        _i2c = &I2C2_Config;
        _i2c->Instance             = I2C2;
    }
#ifdef I2C3_BASE_ADDR
    else if(num == 2){
        /* Configure the GPIO AF */
	    pinmux_iic3_init(scl, sda);
        _i2c = &I2C3_Config;
        _i2c->Instance             = I2C3;
    }
#endif


    _i2c->Init.ClockSpeed      = transfor_i2cFreq(frequency);
    _i2c->Init.OwnAddress1     = 0x51;
    _i2c->Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
    _i2c->Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    _i2c->Init.OwnAddress2     = 0x7E;
    _i2c->Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    _i2c->Init.NoStretchMode   = I2C_NOSTRETCH_DISABLE;  
    
    extern void Error_Handler(void);
    if(HAL_I2C_Init(_i2c) != HAL_OK)
    {
        /* Initialization Error */
        Error_Handler();
    }

    setClock(frequency);

    flush();
    return true;
}

void TwoWire::setTimeOut(uint16_t timeOutMillis)
{
    _timeOutMillis = timeOutMillis;
}

uint16_t TwoWire::getTimeOut()
{
    return _timeOutMillis;
}

void TwoWire::setClock(uint32_t frequency)
{
    i2cSetFrequency(_i2c, frequency);
}

size_t TwoWire::getClock()
{
    return i2cGetFrequency(_i2c);
}

/* stickBreaker Nov 2017 ISR, and bigblock 64k-1
 */
i2c_err_t TwoWire::writeTransmission(uint16_t address, uint8_t *buff, uint16_t size, bool sendStop)
{
    uint8_t hal_i2c_error = 0;
    if(size == 0)
    {
        uint8_t _tx[1] = {0x00};
        hal_i2c_error = HAL_I2C_Master_Transmit(_i2c, (uint16_t)address, _tx, 1, _timeOutMillis);
    }
    else
    {
        hal_i2c_error = HAL_I2C_Master_Transmit(_i2c, (uint16_t)address, buff, size, _timeOutMillis);
    }
    switch (hal_i2c_error)
    {
    case HAL_OK:
        last_error = I2C_ERROR_OK;
        break;
    case HAL_BUSY:
        last_error = I2C_ERROR_BUSY;
        break;
    case HAL_ERROR:
    default:
        last_error = I2C_ERROR_TIMEOUT;
        break;    
    }

    // last_error = i2cWrite(_i2c, address, buff, size, sendStop, _timeOutMillis);
    return last_error;
}

i2c_err_t TwoWire::readTransmission(uint16_t address, uint8_t *buff, uint16_t size, bool sendStop, uint32_t *readCount)
{    
    // uint8_t hal_i2c_error = HAL_I2C_Master_Receive_cnt(_i2c, (uint16_t)address, (uint8_t*)buff, size, _timeOutMillis, readCount);
    *readCount = size - _i2c->XferCount;
    uint8_t hal_i2c_error = HAL_I2C_Master_Receive(_i2c, (uint16_t)address, (uint8_t*)buff, size, _timeOutMillis);
    switch (hal_i2c_error)
    {
    case HAL_OK:
        last_error = I2C_ERROR_OK;
        break;
    case HAL_BUSY:
        last_error = I2C_ERROR_BUSY;
        break;
    case HAL_ERROR:
    default:
        last_error = I2C_ERROR_TIMEOUT;
        break;    
    }

    // last_error = i2cRead(_i2c, address, buff, size, sendStop, _timeOutMillis, readCount);
    return last_error;
}

void TwoWire::beginTransmission(uint16_t address)
{
    transmitting = 1;
    txAddress = address;
    txIndex = txQueued; // allow multiple beginTransmission(),write(),endTransmission(false) until endTransmission(true)
    txLength = txQueued;
    last_error = I2C_ERROR_OK;
}

/*stickbreaker isr
 */
uint8_t TwoWire::endTransmission(bool sendStop)  // Assumes Wire.beginTransaction(), Wire.write()
{
    if(transmitting == 1) {
        // txlength is howmany bytes in txbuffer have been use
        last_error = writeTransmission(txAddress, &txBuffer[txQueued], txLength - txQueued, sendStop);
        if(last_error == I2C_ERROR_CONTINUE){
            txQueued = txLength;
        } else if( last_error == I2C_ERROR_OK){
        rxIndex = 0;
        rxLength = rxQueued;
        rxQueued = 0;
        txQueued = 0; // the SendStop=true will restart all Queueing
        }
    }
    else {
        last_error = I2C_ERROR_NO_BEGIN;
        flush();
    }
    txIndex = 0;
    txLength = 0;
    transmitting = 0;
    return (last_error == I2C_ERROR_CONTINUE)?I2C_ERROR_OK:last_error; // Don't return Continue for compatibility.
}

/* @stickBreaker 11/2017 fix for ReSTART timeout, ISR
 */
uint8_t TwoWire::requestFrom(uint16_t address, uint8_t size, bool sendStop)
{
    //use internal Wire rxBuffer, multiple requestFrom()'s may be pending, try to share rxBuffer
    uint32_t cnt = rxQueued; // currently queued reads, next available position in rxBuffer
    if(cnt < (I2C_BUFFER_LENGTH-1) && (size + cnt) <= I2C_BUFFER_LENGTH) { // any room left in rxBuffer
        rxQueued += size;
    } else { // no room to receive more!
        // log_e("rxBuff overflow %d", cnt + size);
        cnt = 0;
        last_error = I2C_ERROR_MEMORY;
        flush();
        return cnt;
    }

    last_error = readTransmission(address, &rxBuffer[cnt], size, sendStop, &cnt);
    rxIndex = 0;
  
    rxLength = cnt;
  
    if( last_error != I2C_ERROR_CONTINUE){ // not a  buffered ReSTART operation
      // so this operation actually moved data, queuing is done.
        rxQueued = 0;
        txQueued = 0; // the SendStop=true will restart all Queueing or error condition
    }
  
    if(last_error != I2C_ERROR_OK){ // ReSTART on read does not return any data
        cnt = 0;
    }
  
    return cnt;
}

size_t TwoWire::write(uint8_t data)
{
    if(transmitting) {
        if(txLength >= I2C_BUFFER_LENGTH) {
            last_error = I2C_ERROR_MEMORY;
            return 0;
        }
        txBuffer[txIndex] = data;
        ++txIndex;
        txLength = txIndex;
        return 1;
    }
    last_error = I2C_ERROR_NO_BEGIN; // no begin, not transmitting
    return 0;
}

size_t TwoWire::write(const uint8_t *data, size_t quantity)
{
    for(size_t i = 0; i < quantity; ++i) {
        if(!write(data[i])) {
            return i;
        }
    }
    return quantity;

}

int TwoWire::available(void)
{
    int result = rxLength - rxIndex;
    return result;
}

int TwoWire::read(void)
{
    int value = -1;
    if(rxIndex < rxLength) {
        value = rxBuffer[rxIndex];
        ++rxIndex;
    }
    return value;
}

int TwoWire::peek(void)
{
    int value = -1;
    if(rxIndex < rxLength) {
        value = rxBuffer[rxIndex];
    }
    return value;
}

void TwoWire::flush(void)
{
    rxIndex = 0;
    rxLength = 0;
    txIndex = 0;
    txLength = 0;
    rxQueued = 0;
    txQueued = 0;

    // i2cFlush(_i2c); // cleanup
}

uint8_t TwoWire::requestFrom(uint8_t address, uint8_t quantity, uint8_t sendStop)
{
    return requestFrom(static_cast<uint16_t>(address), static_cast<size_t>(quantity), static_cast<bool>(sendStop));
}

uint8_t TwoWire::requestFrom(uint16_t address, uint8_t quantity, uint8_t sendStop)
{
    return requestFrom(address, static_cast<size_t>(quantity), static_cast<bool>(sendStop));
}

uint8_t TwoWire::requestFrom(uint8_t address, uint8_t quantity)
{
    return requestFrom(static_cast<uint16_t>(address), static_cast<size_t>(quantity), true);
}

uint8_t TwoWire::requestFrom(uint16_t address, uint8_t quantity)
{
    return requestFrom(address, static_cast<size_t>(quantity), true);
}

uint8_t TwoWire::requestFrom(int address, int quantity)
{
    return requestFrom(static_cast<uint16_t>(address), static_cast<size_t>(quantity), true);
}

uint8_t TwoWire::requestFrom(int address, int quantity, int sendStop)
{
    return static_cast<uint8_t>(requestFrom(static_cast<uint16_t>(address), static_cast<size_t>(quantity), static_cast<bool>(sendStop)));
}

void TwoWire::beginTransmission(int address)
{
    beginTransmission(static_cast<uint16_t>(address));
}

void TwoWire::beginTransmission(uint8_t address)
{
    beginTransmission(static_cast<uint16_t>(address));
}

uint8_t TwoWire::endTransmission(void)
{
    return endTransmission(true);
}

/* stickbreaker Nov2017 better error reporting
 */
uint8_t TwoWire::lastError()
{
    return (uint8_t)last_error;
}

const char ERRORTEXT[] =
    "OK\0"
    "DEVICE\0"
    "ACK\0"
    "TIMEOUT\0"
    "BUS\0"
    "BUSY\0"
    "MEMORY\0"
    "CONTINUE\0"
    "NO_BEGIN\0"
    "\0";


char * TwoWire::getErrorText(uint8_t err)
{
    uint8_t t = 0;
    bool found = false;
    char * message = (char*)&ERRORTEXT;

    while(!found && message[0]) {
        found = t == err;
        if(!found) {
            message = message + strlen(message) + 1;
            t++;
        }
    }
    if(!found) {
        return NULL;
    } else {
        return message;
    }
}



bool TwoWire::busy(void){
    if(_i2c->State == HAL_I2C_STATE_READY)
    {
        return 0;
    }
    else
    {
        return 1;
    }

//   return ((i2cGetStatus(_i2c) & 16 )==16);    
}

TwoWire Wire = TwoWire(0);
TwoWire Wire1 = TwoWire(1);
#ifdef I2C3_BASE_ADDR
TwoWire Wire1 = TwoWire(2);
#endif