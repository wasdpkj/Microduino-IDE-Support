/* 
  SPI.h - SPI library for LE501X

  Copyright (c) 2015 Hristo Gochkov. All rights reserved.
  This file is part of the LE501X core for Arduino environment.
 
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#ifndef _SPI_H_INCLUDED
#define _SPI_H_INCLUDED

#include <stdlib.h>
#include "Arduino.h"

#include "le501x-hal-spi.h"

#define SPI_HAS_TRANSACTION

#define SPIBUS_SSI      0
#define SPIBUS_SPI      1

#define HSPI    SPIBUS_SPI
#define VSPI    SPIBUS_SSI



#define SPI_MODE0 0
#define SPI_MODE1 1
#define SPI_MODE2 2
#define SPI_MODE3 3

// This defines are not representing the real Divider of the LE501X
// the Defines match on 64MHz for better compatibility
#define SPI_CLOCK_DIV_ERROR     0     //ERROR
#define SPI_CLOCK_DIV2          1     //32 MHz  SSI[2]*,    SPI[N/A]
#define SPI_CLOCK_DIV4          2     //16 MHz  SSI[4]*,    SPI[N/A]
#define SPI_CLOCK_DIV8          3     //8 MHz   SSI[8]*,    SPI[2]
#define SPI_CLOCK_DIV16         4     //4 MHz   SSI[16],    SPI[3]
#define SPI_CLOCK_DIV32         5     //2 MHz   SSI[32],    SPI[4]
#define SPI_CLOCK_DIV64         6     //1 MHz   SSI[64],    SPI[5]
#define SPI_CLOCK_DIV128        7     //500 KHz SSI[128],   SPI[6]
#define SPI_CLOCK_DIV256        8     //250 KHz SSI[256],   SPI[7]

#define SPI_LSBFIRST    LSBFIRST
#define SPI_MSBFIRST    MSBFIRST

/*
 * Helper functions to translate frequency to clock divider and back
 * */
//SPI_CLOCK_DIVx
uint32_t spiFrequencyToClockDiv(uint32_t freq);
uint32_t spiClockDivToFrequency(uint32_t freq);


uint32_t spiGetClockDiv(uint8_t spi_num);
uint8_t spiGetDataMode(uint8_t spi_num);
uint8_t spiGetBitOrder(uint8_t spi_num);

void spiEndTransaction(uint8_t spi_num);

/*
 * Non transaction based lock methods (each locks and unlocks when called)
 * */
void spiSetClockDiv(uint8_t spi_num, uint32_t clockDiv);
void spiSetDataMode(uint8_t spi_num, uint8_t dataMode);
void spiSetBitOrder(uint8_t spi_num, uint8_t bitOrder);

class SPISettings
{
public:
    SPISettings() :_clock(1000000), _bitOrder(MSBFIRST), _dataMode(SPI_MODE0) {}
    SPISettings(uint32_t clock, uint8_t bitOrder, uint8_t dataMode) :_clock(clock), _bitOrder(bitOrder), _dataMode(dataMode) {}
    uint32_t _clock;
    uint8_t  _bitOrder;
    uint8_t  _dataMode;
};

class SPIClass
{
public:
    SPIClass(uint8_t spi_bus=HSPI);
    void begin(int16_t sck=SCK, int16_t miso=MISO, int16_t mosi=MOSI, int16_t ss=-1);
    void end();

    void setBitOrder(uint32_t bitOrder);
    void setDataMode(uint8_t dataMode);
    void setFrequency(uint32_t freq);
    void setClockDivider(uint32_t clockDiv);
    
    uint32_t getClockDivider();

    void beginTransaction(SPISettings settings);
    void endTransaction(void);
    void transfer(uint8_t * data, uint32_t size);
    uint8_t transfer(uint8_t data);
    uint16_t transfer16(uint16_t data);
    uint32_t transfer32(uint32_t data);
  
    void transferBytes(uint8_t * data, uint8_t * out, uint32_t size);

    void write(uint8_t data);
    void write16(uint16_t data);
    void write32(uint32_t data);
    void writeBytes(uint8_t * data, uint32_t size);
    void writePixels(const void * data, uint32_t size);     //ST7789 compatible

private:
    uint8_t _spi_num;
    SPI_HandleTypeDef * _spi;
    SSI_HandleTypeDef * _ssi;
    // bool _use_hw_ss;
    uint8_t _sck;
    uint8_t _miso;
    uint8_t _mosi;
    uint8_t _ss;
    
    uint32_t _div;
    uint32_t _freq;
    bool _inTransaction;
};

extern SPIClass SPI;
extern SPIClass SSI;

// extern SPI_HandleTypeDef SPI2_Config;
// extern SSI_HandleTypeDef SSI_Config;

#endif
