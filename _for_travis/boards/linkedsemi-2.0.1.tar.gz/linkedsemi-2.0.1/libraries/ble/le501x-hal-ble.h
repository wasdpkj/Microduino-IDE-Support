#ifndef _LE501X_BLE_H_INCLUDED
#define _LE501X_BLE_H_INCLUDED

#include <stdlib.h>
#include <string.h>
#include "Arduino.h"

#include "wiring_private.h"

#include "ls_ble.h"
//#include "log.h"
//#include "platform.h"
//#include "prf_diss.h"
//#include "ls_dbg.h"
//#include "cpu.h"
//#include "ls_hal_uart.h"
#include "builtin_timer.h"
#include "co_math.h"
//#include "ls_soc_gpio.h"
//#include "prf_fotas.h"
//#include "SEGGER_RTT.h"


#endif
