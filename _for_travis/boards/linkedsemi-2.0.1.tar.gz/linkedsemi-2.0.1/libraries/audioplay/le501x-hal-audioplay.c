#include "le501x-hal-audioplay.h"

#include "platform.h"
#include "le501x.h"
#include "ls_hal_flash.h"
#include "ls_soc_pinmux.h"
#include "ls_hal_dmac.h"
#include "utility\audio_hw.h"
#include "utility\user_audio_api.h"
#include "log.h"


DEF_DMA_CONTROLLER(dmac1_inst, DMAC1);

struct audio_hw_config user_audio_hw_config = 
{
    .dmac_inst_ptr = &dmac1_inst,
    .dma_channel1 = 1,
    .dma_channel2 = 2,
    .timer_irq = GPTIMC1_IRQn,
    .handshake = CH_LSGPTIM1_UP,
    .timer_inst = LSGPTIMC,
};

void hal_setVolume(uint8_t _val)
{
    api_setVolume(_val);
}    

uint8_t hal_getVolume(void)
{
    return api_getVolume();
}

void user_read_audio_data(uint32_t offset, uint8_t *buf, uint16_t length)
{
    hal_flash_quad_io_read(offset, buf, length);
}

volatile bool audio_play_end_flag = false;
void user_audio_play_end_func(void *param)
{
    *(bool *)param = false;
}

    
void hal_audio_play_init(audioplay_cfg_t* _cfg)
{
    DMA_CONTROLLER_INIT(dmac1_inst);
    audio_hw_init(&user_audio_hw_config);

    _cfg->mode = USER_AUDIO_OUTPUT_MODE;    //输出模式
    _cfg->bit = USER_AUDIO_RESOLUTION;      //分辨率
    _cfg->rate = AUDIO_SAMPLERATE_8K;       //采样率
    _cfg->format = USER_AUDIO_FORMAT;       //编码格式

    // adtim1_ch1_io_init(_cfg.pinA, true, 0);
    pinmux_gptimc1_ch1_init(_cfg->pinA, true, 0);
#if USER_AUDIO_OUTPUT_MODE == AUDIO_OUTPUT_MODE_DIFFERENTIAL    
    // adtim1_ch2_io_init(_cfg.pinB, true, 0);
    pinmux_gptimc1_ch2_init(_cfg->pinB, true, 0);
#endif
}

void hal_audio_play_deinit()
{
    audio_hw_deinit();
}

void hal_audio_play(uint32_t _addr, uint32_t _len)
{
    audio_play_end_flag = true;
    audio_start(_addr, _len, &user_audio_play_end_func, (void*)&audio_play_end_flag);
}


bool hal_isPlaying(void)
{
    if(audio_play_end_flag)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void hal_audio_stop(void)
{
    audio_stop();
}
