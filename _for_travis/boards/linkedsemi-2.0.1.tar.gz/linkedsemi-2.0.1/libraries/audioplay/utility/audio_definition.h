#ifndef AUDIO_DEFINITION_H_
#define AUDIO_DEFINITION_H_

#ifdef __cplusplus
  extern "C" {
#endif

#define AUDIO_ADPCM 1
#define AUDIO_PCM 2
#define AUDIO_SBC 3
#define AUDIO_OPUS 4

#define AUDIO_OUTPUT_MODE_DIFFERENTIAL 0
#define AUDIO_OUTPUT_MODE_SINGLE_END 1

#define AUDIO_SAMPLERATE_8K 8000
#define AUDIO_SAMPLERATE_16K 16000

#define AUDIO_RESOLUTION_8BIT 1
#define AUDIO_RESOLUTION_16BIT 2

#define AUDIO_PCM_UNSIGNED 0
#define AUDIO_PCM_SIGNED 1

#define AUDIO_PCM_VOLUME_DEFAULT 0
#define AUDIO_PCM_VOLUME_1_2 1
#define AUDIO_PCM_VOLUME_1_4 2
#define AUDIO_PCM_VOLUME_1_8 3
#define AUDIO_PCM_VOLUME_1_16 4

#ifdef __cplusplus
};
#endif

#endif
