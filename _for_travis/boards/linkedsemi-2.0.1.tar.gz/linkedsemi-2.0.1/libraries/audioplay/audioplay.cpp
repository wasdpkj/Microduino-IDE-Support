/* Copyright 2023 Panda
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "audioplay.h"
#include "log.h"

static bool _onceInstance = 0;
void AUDIOPLAY::stopPlaying(void)
{
    hal_audio_stop();
}

bool AUDIOPLAY::isPlaying(void)
{
    return hal_isPlaying();
}


void AUDIOPLAY::setVolume(uint8_t _val)
{
    if(_val > 4)
    {
        _val = 4;
    }
    hal_setVolume(4 - _val);
}


uint8_t AUDIOPLAY::getVolume(void)
{
    return (4 - hal_getVolume());
}


bool AUDIOPLAY::playRAM(uint8_t* _data)
{
    uint32_t _addr = 0;
    uint32_t _len = 0;

    if((_data[8] == 'W') && (_data[9] == 'A') && (_data[10] == 'V') && (_data[11] == 'E'))
    {
        // LOG_RAW("format is wav!!\r\n");
        _addr = (uint32_t)&_data[0] + 44;
        _len = _data[40] | (_data[41] << 8) | (_data[42] << 16) | (_data[43] << 24);
        // LOG_RAW("_addr = %x, _len = %x\r\n", _addr, _len);

        if(this->isPlaying())
        {
            this->stopPlaying();
        }

        hal_audio_play(_addr, _len);

        return true;
    }
    else
    {
        // LOG_RAW("format error!\r\n");
        audio_play_end_flag = false;
    }

    return false;
}



bool AUDIOPLAY::playRAM(uint8_t *_data, uint32_t _len)
{
    uint32_t _addr = 0;

    _addr = (uint32_t)&_data[0] + 44;

    if(this->isPlaying())
    {
        this->stopPlaying();
    }

    hal_audio_play(_addr, _len);

    return true;
}

bool AUDIOPLAY::playROM(const uint8_t *_data, uint32_t _len)
{
    return playRAM((uint8_t*)_data, _len);
}

bool AUDIOPLAY::playROM(const uint8_t *_data)
{
    return playRAM((uint8_t*)_data);
}


bool AUDIOPLAY::init(audioplay_cfg_t* _cfg)
{
    if(_onceInstance)
    {
        LOG_RAW("Multiple instances are not allowed\r\n");
        return false;
    }
    _onceInstance = 1;

    hal_audio_play_init(_cfg);
    return true;
}


void AUDIOPLAY::deinit()
{
    _onceInstance = 0;

    hal_audio_play_deinit();
}

