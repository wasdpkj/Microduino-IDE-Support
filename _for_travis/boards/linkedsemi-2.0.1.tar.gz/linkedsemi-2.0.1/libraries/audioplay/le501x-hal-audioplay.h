#ifndef MAIN_LE501X_HAL_AUDIOPLAY_H_
#define MAIN_LE501X_HAL_AUDIOPLAY_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

typedef struct 
{
	uint8_t mode;   //模式
    uint8_t bit;    //分辨率
	uint16_t rate;  //采样率
	uint8_t format; //编码格式
    uint8_t pinA;
    uint8_t pinB;
}audioplay_cfg_t;


void user_audio_play_end_func(void *param);

void hal_setVolume(uint8_t _val);
uint8_t hal_getVolume(void);
void hal_audio_play_init(audioplay_cfg_t* _cfg);
void hal_audio_play_deinit();

void hal_audio_play(uint32_t audio_base, uint32_t audio_length);
void hal_audio_stop(void);
bool hal_isPlaying(void);

extern volatile bool audio_play_end_flag;

#ifdef __cplusplus
}
#endif

#endif /* MAIN_LE501X_HAL_AUDIOPLAY_H_ */
