/* Copyright 2021 Panda
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef _AUDIOPLAY_H_
#define _AUDIOPLAY_H_



#include "Arduino.h"


// #include <stdint.h>
// #include <stdbool.h>
// #include <string.h>

// #include "log.h"
// #include "platform.h"

// #include "le501x-hal-gpio.h"
#include "le501x-hal-audioplay.h"

#define AUDIO_VOLUME_0 		0
#define AUDIO_VOLUME_1 		1
#define AUDIO_VOLUME_2 		2
#define AUDIO_VOLUME_3 		3
#define AUDIO_VOLUME_4 		4

class AUDIOPLAY
{
private:


public:

	bool init(audioplay_cfg_t* _cfg);
	void deinit();
	void stopPlaying(void);
	bool isPlaying(void);
	bool playRAM(uint8_t* _data);
	bool playRAM(uint8_t *_data, uint32_t _len);	
	bool playROM(const uint8_t* _data);
	bool playROM(const uint8_t *_data, uint32_t _len);	
	void setVolume(uint8_t _val);
	uint8_t getVolume( void);

};


#ifdef __cplusplus
  extern "C" {
#endif


#ifdef __cplusplus
};
#endif

#endif