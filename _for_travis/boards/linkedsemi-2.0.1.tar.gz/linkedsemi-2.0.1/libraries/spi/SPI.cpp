/*
 SPI.cpp - SPI library for LE501X

 Copyright (c) 2015 Hristo Gochkov. All rights reserved.
 This file is part of the LE501X core for Arduino environment.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "SPI.h"

// SSI_HandleTypeDef SSI1_Config;
static SPI_HandleTypeDef SPI2_Config;
static SSI_HandleTypeDef SSI_Config;


const uint32_t _spiClockDiv[8] = {
    SPI_CLOCK_DIV_ERROR, SPI_CLOCK_DIV_ERROR, SPI_CLOCK_DIV8, SPI_CLOCK_DIV16,
    SPI_CLOCK_DIV32, SPI_CLOCK_DIV64, SPI_CLOCK_DIV128, SPI_CLOCK_DIV256};

static uint16_t sumReg(uint16_t _reg)
{
    if (_reg < 2 || _reg > 256)
        return 0;

    _reg &= 0xFFFE;
    uint16_t i = 0;
    while (i < 10)
    {
        if ((_reg >> i) < 1)
        {
            return i - 1;
        }
        i++;
    }

    return 0;
}

void spiEndTransaction(uint8_t spi_num)
{
    if (spi_num == VSPI)
    {
    }
    else
    {
    }
}

uint32_t spiGetClockDiv(uint8_t spi_num)
{
    uint32_t _reg;
    if (spi_num == VSPI)
    {
        reg_ssi_t *_ssiconfig;
        _ssiconfig = LSSSI;
        _reg = REG_FIELD_RD(_ssiconfig->BAUDR, SSI_SCKDV);

        return (sumReg(_reg) & 0xFFFF);
    }
    else
    {
        reg_spi_t *_spiconfig;
        _spiconfig = SPI2;
        _reg = REG_FIELD_RD(_spiconfig->CR1, SPI_CR1_BR);
        _reg += 1;
        return _reg;
    }

}

void spiSetClockDiv(uint8_t spi_num, uint32_t clockDiv)
{
    // Serial.print("spiSetClockDiv");
    // Serial.print(", spi_num: ");
    // Serial.print(spi_num);
    // Serial.print(",clockDiv: ");
    // Serial.println(clockDiv);

    uint32_t _div_raw = 0;
    if (spi_num == VSPI)
    {
        reg_ssi_t *_ssiconfig;
        _ssiconfig = LSSSI;
        
        if(clockDiv < 1) clockDiv = 1;

        _div_raw = 0xFFFF & (1 << clockDiv);
        // Serial.print("[VSPI]_div_raw: ");
        // Serial.println(_div_raw);
        REG_FIELD_WR(_ssiconfig->BAUDR, SSI_SCKDV, _div_raw);

        // 64M: 2[ok], 4[ok], 8[ok], 16[显示抽风],
        // 32M: 2[ok], 4[ok], 8[ok], 16[ok], 32[显示抽风]
        // 16M: 2[ok], 4[ok], 8[ok], 16[小抽风]
        //  REG_FIELD_WR(_ssiconfig->BAUDR, SSI_SCKDV, 0xFFFF & (32));
    }
    else
    {
        reg_spi_t *_spiconfig;
        _spiconfig = SPI2;

        if(clockDiv < 3) clockDiv = 3;

       _div_raw = 0x07 & (clockDiv - 1);
        // Serial.print("[HSPI]_div_raw: ");
        // Serial.println(_div_raw);    
        REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_BR, _div_raw);
    }

    // if(!spi) {
    //     return;
    // }
    // SPI_MUTEX_LOCK();
    // spi->dev->clock.val = clockDiv;
    // SPI_MUTEX_UNLOCK();
}

uint8_t spiGetDataMode(uint8_t spi_num)
{
    bool idleEdge = 0x00, outEdge = 0x00;
    if (spi_num == VSPI)
    {
        reg_ssi_t *_ssiconfig;
        _ssiconfig = LSSSI;

        idleEdge = REG_FIELD_RD(_ssiconfig->CTRLR0, SSI_SCPOL);
        outEdge = REG_FIELD_RD(_ssiconfig->CTRLR0, SSI_SCPH);
    }
    else
    {
        reg_spi_t *_spiconfig;
        _spiconfig = SPI2;

        idleEdge = REG_FIELD_RD(_spiconfig->CR1, SPI_CR1_CPOL);
        outEdge = REG_FIELD_RD(_spiconfig->CR1, SPI_CR1_CPHA);
    }

    if (idleEdge)
    {
        if (outEdge)
        {
            return SPI_MODE2;
        }
        return SPI_MODE3;
    }
    if (outEdge)
    {
        return SPI_MODE1;
    }
    return SPI_MODE0;
}

void spiSetDataMode(uint8_t spi_num, uint8_t dataMode)
{
    if (spi_num == VSPI)
    {
        reg_ssi_t *_ssiconfig;
        _ssiconfig = LSSSI;

        switch (dataMode)
        {
        case SPI_MODE1:
            REG_FIELD_WR(_ssiconfig->CTRLR0, SSI_SCPOL, 0x00);
            REG_FIELD_WR(_ssiconfig->CTRLR0, SSI_SCPH, 0x01);
            // MODIFY_REG(_ssiconfig->CTRLR0,
            //            (SSI_SCPOL_MASK | SSI_SCPH_MASK),
            //            (FIELD_BUILD(SSI_SCPOL, 0x00) | FIELD_BUILD(SSI_SCPH, 0x01)));
            break;
        case SPI_MODE2:
            REG_FIELD_WR(_ssiconfig->CTRLR0, SSI_SCPOL, 0x01);
            REG_FIELD_WR(_ssiconfig->CTRLR0, SSI_SCPH, 0x01);
            break;
        case SPI_MODE3:
            REG_FIELD_WR(_ssiconfig->CTRLR0, SSI_SCPOL, 0x01);
            REG_FIELD_WR(_ssiconfig->CTRLR0, SSI_SCPH, 0x00);
            break;
        case SPI_MODE0:
        default:
            REG_FIELD_WR(_ssiconfig->CTRLR0, SSI_SCPOL, 0x00);
            REG_FIELD_WR(_ssiconfig->CTRLR0, SSI_SCPH, 0x00);
            break;
        }
    }
    else
    {
        reg_spi_t *_spiconfig;
        _spiconfig = SPI2;

        switch (dataMode)
        {
        case SPI_MODE1:
            REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_CPOL, 0x00);
            REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_CPHA, 0x01);
            // MODIFY_REG(_spiconfig->CR1,
            //            (SPI_CR1_CPOL_MASK | SPI_CR1_CPHA_MASK),
            //            (FIELD_BUILD(SPI_CR1_CPOL, 0x00) | FIELD_BUILD(SPI_CR1_CPHA, 0x01)));
            break;
        case SPI_MODE2:
            REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_CPOL, 0x01);
            REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_CPHA, 0x01);
            break;
        case SPI_MODE3:
            REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_CPOL, 0x01);
            REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_CPHA, 0x00);
            break;
        case SPI_MODE0:
        default:
            REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_CPHA, 0x00);
            REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_CPOL, 0x00);
            break;
        }
    }

    // if(!spi) {
    //     return;
    // }
    // SPI_MUTEX_LOCK();
    // switch (dataMode) {
    // case SPI_MODE1:
    //     spi->dev->pin.ck_idle_edge = 0;
    //     spi->dev->user.ck_out_edge = 1;
    //     break;
    // case SPI_MODE2:
    //     spi->dev->pin.ck_idle_edge = 1;
    //     spi->dev->user.ck_out_edge = 1;
    //     break;
    // case SPI_MODE3:
    //     spi->dev->pin.ck_idle_edge = 1;
    //     spi->dev->user.ck_out_edge = 0;
    //     break;
    // case SPI_MODE0:
    // default:
    //     spi->dev->pin.ck_idle_edge = 0;
    //     spi->dev->user.ck_out_edge = 0;
    //     break;
    // }
    // SPI_MUTEX_UNLOCK();
}

uint8_t spiGetBitOrder(uint8_t spi_num)
{
    if (spi_num == VSPI)
    {
        return SPI_MSBFIRST;
    }
    else
    {
        reg_spi_t *_spiconfig;
        _spiconfig = SPI2;
        if (REG_FIELD_RD(_spiconfig->CR1, SPI_CR1_LSBFIRST) == 0x01)
        {
            return SPI_LSBFIRST;
        }
        else
        {
            return SPI_MSBFIRST;
        }
    }
}

void spiSetBitOrder(uint8_t spi_num, uint8_t bitOrder)
{
    if (spi_num == VSPI)
    {
        return;
    }
    else
    {
        reg_spi_t *_spiconfig;
        _spiconfig = SPI2;
        if (bitOrder == SPI_MSBFIRST)
        {
            REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_LSBFIRST, 0x00);
        }
        else
        {
            REG_FIELD_WR(_spiconfig->CR1, SPI_CR1_LSBFIRST, 0x01);
        }
    }

    // if(!spi) {
    //     return;
    // }
    // SPI_MUTEX_LOCK();
    // if (SPI_MSBFIRST == bitOrder) {
    //     spi->dev->ctrl.wr_bit_order = 0;
    //     spi->dev->ctrl.rd_bit_order = 0;
    // } else if (SPI_LSBFIRST == bitOrder) {
    //     spi->dev->ctrl.wr_bit_order = 1;
    //     spi->dev->ctrl.rd_bit_order = 1;
    // }
    // SPI_MUTEX_UNLOCK();
}

uint32_t spiClockDivToFrequency(uint32_t clockDiv)
{
    uint32_t _spi_freq = SPI_CLOCK / (1 << clockDiv);

    // Serial.print("spiClockDivToFrequency, SPI_CLOCK = ");
    // Serial.print(SPI_CLOCK);
    // Serial.print(",clockDiv = ");
    // Serial.print(clockDiv);
    // Serial.print(",out_freq = ");
    // Serial.println(_spi_freq);
    return _spi_freq;
}

uint32_t spiFrequencyToClockDiv(uint32_t freq)
{
    if(freq > SPI_CLOCK / 2)
    {
        freq = SPI_CLOCK / 2;
    }

    uint32_t _spi_div = (SPI_CLOCK + 1) / freq;

    // Serial.print("spiFrequencyToClockDiv, SPI_CLOCK = ");
    // Serial.print(SPI_CLOCK);
    // Serial.print(",spi_freq = ");
    // Serial.print(freq);
    // Serial.print(",out_div = ");
    // Serial.println(_spi_div);
    return sumReg(_spi_div);
}


SPIClass::SPIClass(uint8_t spi_bus)
    : _spi_num(spi_bus), _spi(NULL), _ssi(NULL)
      // ,_use_hw_ss(false)
      ,
      _sck(-1), _miso(-1), _mosi(-1), _ss(-1), _div(0), _freq(1000000), _inTransaction(false)
{
}

void SPIClass::begin(int16_t sck, int16_t miso, int16_t mosi, int16_t ss)
{

    if (_spi_num == HSPI)
    {
        if (_spi)
        {
            return;
        }

        /* Configure the GPIO AF */

        if (sck != -1)
        {
            _sck = (uint8_t)sck;
            // io_pull_write(_sck, IO_PULL_DOWN); // config pulldown
            pinmux_spi2_master_clk_init(_sck, SPI_POLARITY_LOW);
        }
        else
        {
            return;
        }

        if (miso != -1)
        {
            _miso = (uint8_t)miso;
            io_pull_write(_miso, IO_PULL_DOWN); // config pulldown
            pinmux_spi2_master_miso_init(_miso);
        }
        else
        {
            _miso = 0xFF;
        }

        if (mosi != -1)
        {
            _mosi = (uint8_t)mosi;
            pinmux_spi2_master_mosi_init(_mosi);
        }
        else
        {
            _mosi = 0xFF;
        }

        if (ss != -1)
        {
            _ss = (uint8_t)ss;
            pinMode(_ss, OUTPUT);
            digitalWrite(_ss, HIGH);
        }
        else
        {
            _ss = 0xFF;
        }

        // Serial.printf("00 _spi: %x\r\n", (uint8_t*)_spi);
        _spi = &SPI2_Config;
        // Serial.printf("11 _spi: %x\r\n", (uint8_t*)_spi);
        _spi->Instance = SPI2;
        _spi->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
        _spi->Init.CLKPolarity = SPI_POLARITY_LOW;
        _spi->Init.CLKPhase = SPI_PHASE_1EDGE;
        _spi->Init.DataSize = SPI_DATASIZE_8BIT;
        _spi->Init.FirstBit = SPI_FIRSTBIT_MSB;
        _spi->Init.TIMode = SPI_TIMODE_DISABLE;

        _spi->Init.Mode = SPI_MODE_MASTER;

#if 0
        Serial.print("sck: 0x");
        Serial.print(_sck, HEX);
        Serial.print(", miso: 0x");
        Serial.print(_miso, HEX);
        Serial.print(", mosi: 0x");
        Serial.print(_mosi, HEX);
        Serial.print(", ss: 0x");
        Serial.print(_ss, HEX);
        Serial.println("");
#endif

        extern void Error_Handler(void);
        if (HAL_SPI_Init(_spi) != HAL_OK)
        {
            /* Initialization Error */
            Error_Handler();
        }
    }
    else if (_spi_num == VSPI)
    {
        if (_ssi)
        {
            return;
        }

        /* Configure the GPIO AF */

        if (sck != -1)
        {
            _sck = (uint8_t)sck;
            // io_pull_write(_sck, IO_PULL_UP); // config pullup
            pinmux_ssi_clk_init(_sck, Inactive_Low);
            // io_pull_write(_sck, IO_PULL_DOWN); // config pullup
        }
        else
        {
            return;
        }

        if (miso != -1)
        {
            _miso = (uint8_t)miso;
            pinmux_ssi_dq1_init(_miso);
            // io_pull_write(_miso, IO_PULL_UP); // config pullup
        }
        else
        {
            _miso = 0xFF;
        }

        if (mosi != -1)
        {
            _mosi = (uint8_t)mosi;
            pinmux_ssi_dq0_init(_mosi);
        }
        else
        {
            _mosi = 0xFF;
        }

        if (ss != -1)
        {
            _ss = (uint8_t)ss;
            pinMode(_ss, OUTPUT);
            digitalWrite(_ss, HIGH);
        }
        else
        {
            _mosi = 0xFF;
        }

        _ssi = &SSI_Config;
        _ssi->REG = LSSSI;
        _ssi->Init.clk_div = 2; // 2~8 for TFT
        _ssi->Init.rxsample_dly = 0;
        _ssi->Init.ctrl.frame_format = Motorola_SPI;
        _ssi->Init.ctrl.cpol = 0;
        _ssi->Init.ctrl.cph = 0;
        // _ssi->Init.ctrl.cpol = 0;
        // _ssi->Init.ctrl.cph = 0;
        _ssi->Init.ctrl.data_frame_size = DFS_32_8_bits;

        extern void Error_Handler(void);
        if (HAL_SSI_Init(_ssi) != HAL_OK)
        {
            /* Initialization Error */
            Error_Handler();
        }
    }
}

void SPIClass::end()
{

    if (_spi_num == HSPI)
    {

        if (!_spi)
        {
            return;
        }

        if (_sck != 0xFF)
        {
            pinmux_spi2_clk_deinit();
        }

        if (_miso != 0xFF)
        {
            pinmux_spi2_miso_deinit();
        }

        if (_mosi != 0xFF)
        {
            pinmux_spi2_mosi_deinit();
        }

        if (_ss != 0xFF)
        {
            pinMode(_ss, INPUT);
        }

        HAL_SPI_DeInit(_spi);
        _spi = NULL;
    }
    else if (_spi_num == VSPI)
    {
        if (!_ssi)
        {
            return;
        }

        if (_sck != 0xFF)
        {
            pinmux_ssi_clk_deinit();
        }

        if (_miso != 0xFF)
        {
            pinmux_ssi_dq1_deinit();
        }

        if (_mosi != 0xFF)
        {
            pinmux_ssi_dq0_deinit();
        }

        if (_ss != 0xFF)
        {
            pinMode(_ss, INPUT);
        }

        HAL_SSI_Deinit(_ssi);
        _spi = NULL;
    }
}

void SPIClass::setFrequency(uint32_t freq)
{
#if 1
    return;

    // Serial.println("setFrequency -->");

    // check if last freq changed
    uint32_t cdiv = spiGetClockDiv(_spi_num);
    if (_freq != freq || _div != cdiv)
    {
        _freq = freq;
        _div = spiFrequencyToClockDiv(_freq);
        spiSetClockDiv(_spi_num, _div);
    }
#else
    // check if last freq changed
    uint32_t cdiv = spiGetClockDiv(_spi);
    if (_freq != freq || _div != cdiv)
    {
        _freq = freq;
        _div = spiFrequencyToClockDiv(_freq);
        spiSetClockDiv(_spi, _div);
    }
#endif
}

void SPIClass::setClockDivider(uint32_t clockDiv)
{
#if 1
    // Serial.println("SPIClass::setClockDivider -->");
    if (_spi_num == VSPI)
    {
        if (!_ssi)
        {
            return;
        }
        _ssi->Init.clk_div = 0xFFFF & (clockDiv);
    }
    else if (_spi_num == HSPI)
    {
        if (!_spi)
        {
            return;
        }
        _spi->Init.BaudRatePrescaler = 0x07 & (uint32_t(clockDiv - 1) << SPI_CR1_BR_POS);
    }


    spiSetClockDiv(_spi_num, clockDiv);
#else
    if (_spi_num == VSPI)
    {
        if (!_ssi)
        {
            return;
        }

        return;
    }

    if (!_spi)
    {
        return;
    }

    // Serial.printf("0 _spi: %x\r\n", (uint8_t*)_spi);
    HAL_SPI_DeInit(_spi);

    // _spi = &SPI2_Config;
    // Serial.printf("1 _spi: %x\r\n", (uint8_t*)_spi);

    // _spi->Instance = SPI2;
    // _spi->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
    _spi->Init.BaudRatePrescaler = clockDiv;
    // _spi->Init.CLKPhase = SPI_PHASE_1EDGE;
    // _spi->Init.CLKPolarity = SPI_POLARITY_HIGH;
    // _spi->Init.DataSize = SPI_DATASIZE_8BIT;
    // _spi->Init.FirstBit = SPI_FIRSTBIT_MSB;
    // _spi->Init.TIMode = SPI_TIMODE_DISABLE;

    // _spi->Init.Mode = SPI_MODE_MASTER;

    extern void Error_Handler(void);
    if (HAL_SPI_Init(_spi) != HAL_OK)
    {
        /* Initialization Error */
        Error_Handler();
    }
#endif
}

uint32_t SPIClass::getClockDivider()
{
    if (_spi_num == VSPI)
    {
        if (!_ssi)
        {
            return 0;
        }
    }
    else
    {
        if (!_spi)
        {
            return 0;
        }
    }

    return spiGetClockDiv(_spi_num);
}

void SPIClass::setDataMode(uint8_t dataMode)
{
    if (_spi_num == VSPI)
    {
        if (!_ssi)
        {
            return;
        }

        switch (dataMode)
        {
        case SPI_MODE1:
            _ssi->Init.ctrl.cpol = 0;
            _ssi->Init.ctrl.cph = 1;
            io_pull_write(_sck, IO_PULL_DOWN); // config pulldown
            break;
        case SPI_MODE2:
            _ssi->Init.ctrl.cpol = 1;
            _ssi->Init.ctrl.cph = 1;
            io_pull_write(_sck, IO_PULL_UP); // config pullup
            break;
        case SPI_MODE3:
            _ssi->Init.ctrl.cpol = 1;
            _ssi->Init.ctrl.cph = 0;
            io_pull_write(_sck, IO_PULL_UP); // config pullup
            break;
        case SPI_MODE0:
        default:
            _ssi->Init.ctrl.cpol = 0;
            _ssi->Init.ctrl.cph = 0;
            io_pull_write(_sck, IO_PULL_DOWN); // config pulldown
            break;
        }
    }
    else
    {
        if (!_spi)
        {
            return;
        }

        switch (dataMode)
        {
        case SPI_MODE1:
            _spi->Init.CLKPolarity = SPI_POLARITY_LOW; // SPI_POLARITY_LOW
            _spi->Init.CLKPhase = SPI_PHASE_2EDGE;     // SPI_PHASE_2EDGE
            io_pull_write(_sck, IO_PULL_DOWN);         // config pulldown
            break;
        case SPI_MODE2:
            _spi->Init.CLKPolarity = SPI_POLARITY_HIGH; // SPI_POLARITY_HIGH
            _spi->Init.CLKPhase = SPI_PHASE_2EDGE;      // SPI_PHASE_2EDGE
            io_pull_write(_sck, IO_PULL_UP);            // config pullup
            break;
        case SPI_MODE3:
            _spi->Init.CLKPolarity = SPI_POLARITY_HIGH; // SPI_POLARITY_HIGH
            _spi->Init.CLKPhase = SPI_PHASE_1EDGE;      // SPI_PHASE_1EDGE
            io_pull_write(_sck, IO_PULL_UP);            // config pullup
            break;
        case SPI_MODE0:
        default:
            _spi->Init.CLKPolarity = SPI_POLARITY_LOW; // SPI_POLARITY_LOW
            _spi->Init.CLKPhase = SPI_PHASE_1EDGE;     // SPI_PHASE_1EDGE
            io_pull_write(_sck, IO_PULL_DOWN);         // config pulldown
            break;
        }
    }

    spiSetDataMode(_spi_num, dataMode);
}

void SPIClass::setBitOrder(uint32_t bitOrder)
{
    if (_spi_num == VSPI)
    {
        if (!_ssi)
        {
            return;
        }
        return;
    }
    else
    {
        if (!_spi)
        {
            return;
        }
    }

    spiSetBitOrder(_spi_num, bitOrder);
}

void SPIClass::beginTransaction(SPISettings settings)
{
#if 1
    _inTransaction = true;

    // check if last freq changed
    uint32_t cdiv;
    cdiv = getClockDivider();
    if (_freq != settings._clock || _div != cdiv)
    {
        _freq = settings._clock;
        _div = spiFrequencyToClockDiv(_freq);
        // Serial.print("\r\nspiFrequencyToClockDiv: ");
        // Serial.println(_div);
    }

    setClockDivider(_div);
    setBitOrder(settings._bitOrder);
    setDataMode(settings._dataMode);

    // spiSetClockDiv(_spi_num, _div);
    // spiSetBitOrder(_spi_num, settings._bitOrder);
    // spiTransaction(_spi, _div, settings._dataMode, settings._bitOrder);
#elif 1
    _inTransaction = true;

    // check if last freq changed
    uint32_t cdiv;
    cdiv = spiGetClockDiv(_spi_num);
    if (_freq != settings._clock || _div != cdiv)
    {
        _freq = settings._clock;
        _div = spiFrequencyToClockDiv(_freq);
    }

    spiSetClockDiv(_spi_num, _div);
    spiSetBitOrder(_spi_num, settings._bitOrder);
    // setBitOrder(settings._bitOrder);
    setDataMode(settings._dataMode);
    // spiTransaction(_spi, _div, settings._dataMode, settings._bitOrder);
#else
    // check if last freq changed
    uint32_t cdiv = spiGetClockDiv(_spi);
    if (_freq != settings._clock || _div != cdiv)
    {
        _freq = settings._clock;
        _div = spiFrequencyToClockDiv(_freq);
    }
    spiTransaction(_spi, _div, settings._dataMode, settings._bitOrder);
    _inTransaction = true;
#endif
}

void SPIClass::endTransaction()
{
#if 1
    if (_inTransaction)
    {
        _inTransaction = false;
        spiEndTransaction(_spi_num);
    }
#else
    if (_inTransaction)
    {
        _inTransaction = false;
        spiEndTransaction(_spi);
    }
#endif
}

void SPIClass::write(uint8_t data)
{
#if 1
    uint8_t _txdata[1];
    _txdata[0] = data;

    if (_spi_num == VSPI)
    {
        // HAL_SSI_Transmit_FAST(_ssi, (uint8_t *)_txdata, 1);
        HAL_SSI_Transmit(_ssi, (uint8_t *)_txdata, 1);
    }
    else
    {
        HAL_SPI_Transmit_FAST(_spi, (uint8_t *)_txdata, 1);
        // HAL_SPI_Transmit(_spi, (uint8_t*)_txdata, 1, 10000);
        // HAL_SPI_Transmit_IT(_spi, (uint8_t*)_txdata, 1);
        // HAL_SPI_Transmit_DMA(_spi, (uint8_t*)_txdata, 1);
    }
#else
    if (_inTransaction)
    {
        return spiWriteByteNL(_spi, data);
    }
    spiWriteByte(_spi, data);
#endif
}

#if 1
uint8_t SPIClass::transfer(uint8_t data)
{
#if 1
    uint8_t _txdata[1];
    uint8_t _rxdata[1];
    _txdata[0] = data;

    if (_spi_num == VSPI)
    {
        HAL_SSI_TransmitReceive(_ssi, (uint8_t *)_txdata, (uint8_t *)_rxdata, 1);
        // HAL_SSI_Receive(_ssi, (uint8_t *)_rxdata, 1);
    }
    else
    {
        HAL_SPI_TransmitReceive(_spi, (uint8_t *)_txdata, (uint8_t *)_rxdata, 1, 10000);
        // HAL_SPI_Receive(_spi, (uint8_t *)_rxdata, 1, 10000);
    }

    return _rxdata[0];
#else
    if (_inTransaction)
    {
        return spiTransferByteNL(_spi, data);
    }
    return spiTransferByte(_spi, data);
#endif
}
#endif

// panda writePixel
void SPIClass::write16(uint16_t data)
{
#if 1
    uint8_t _txdata[2];
    _txdata[0] = (0xFF & (data >> 8));
    _txdata[1] = (0xFF & data);

    if (_spi_num == VSPI)
    {
        // HAL_SSI_Transmit_FAST(_ssi, (uint8_t *)_txdata, 2);
        HAL_SSI_Transmit(_ssi, (uint8_t *)_txdata, 2);
    }
    else
    {
        HAL_SPI_Transmit_FAST(_spi, (uint8_t *)_txdata, 2);
        // HAL_SPI_Transmit(_spi, (uint8_t *)_txdata, 2, 10000);
        // HAL_SPI_Transmit_IT(_spi, (uint8_t *)_txdata, 2);
        // HAL_SPI_Transmit_DMA(_spi, (uint8_t *)_txdata, 2);
    }
#else
    if (_inTransaction)
    {
        return spiWriteShortNL(_spi, data);
    }
    spiWriteWord(_spi, data);
#endif
}

#if 1
uint16_t SPIClass::transfer16(uint16_t data)
{
#if 1
    uint8_t _txdata[2];
    uint8_t _rxdata[2];
    _txdata[0] = (0xFF & (data >> 8));
    _txdata[1] = (0xFF & data);

    if (_spi_num == VSPI)
    {
        HAL_SSI_TransmitReceive(_ssi, (uint8_t *)_txdata, (uint8_t *)_rxdata, 2);
    }
    else
    {
        HAL_SPI_TransmitReceive(_spi, (uint8_t *)_txdata, (uint8_t *)_rxdata, 2, 10000);
    }

    return PACKAGE16(_rxdata[0], _rxdata[1]);
    // uint16_t _outrxdata = (0xFF00 & (_rxdata[0] << 8)) || (0x00FF & (_txdata[1]));
    // return _outrxdata;
#else
    if (_inTransaction)
    {
        return spiTransferShortNL(_spi, data);
    }
    return spiTransferWord(_spi, data);
#endif
}
#endif

// panda setAddrWindow
void SPIClass::write32(uint32_t data)
{
#if 1
    uint8_t _txdata[4];
    _txdata[0] = (0xFF & (data >> 24));
    _txdata[1] = (0xFF & (data >> 16));
    _txdata[2] = (0xFF & (data >> 8));
    _txdata[3] = (0xFF & data);

    if (_spi_num == VSPI)
    {
        // HAL_SSI_Transmit_FAST(_ssi, (uint8_t *)_txdata, 4);
        HAL_SSI_Transmit(_ssi, (uint8_t *)_txdata, 4);
    }
    else
    {
        HAL_SPI_Transmit_FAST(_spi, (uint8_t *)_txdata, 4);
        // HAL_SPI_Transmit(_spi, (uint8_t*)_txdata, 4, 10000);
        // HAL_SPI_Transmit_IT(_spi, (uint8_t*)_txdata, 4);
        // HAL_SPI_Transmit_DMA(_spi, (uint8_t*)_txdata, 4);
    }
#else
    if (_inTransaction)
    {
        return spiWriteLongNL(_spi, data);
    }
    spiWriteLong(_spi, data);
#endif
}

#if 1
uint32_t SPIClass::transfer32(uint32_t data)
{
#if 1
    uint8_t _txdata[4];
    uint8_t _rxdata[4];
    _txdata[0] = (0xFF & (data >> 24));
    _txdata[1] = (0xFF & (data >> 16));
    _txdata[2] = (0xFF & (data >> 8));
    _txdata[3] = (0xFF & data);

    if (_spi_num == VSPI)
    {
        HAL_SSI_TransmitReceive(_ssi, (uint8_t *)_txdata, (uint8_t *)_rxdata, 4);
        // HAL_SSI_Receive(_ssi, (uint8_t *)_rxdata, 4);
    }
    else
    {
        HAL_SPI_TransmitReceive(_spi, (uint8_t *)_txdata, (uint8_t *)_rxdata, 4, 10000);
        // HAL_SPI_Receive(_spi, (uint8_t *)_rxdata, 4, 10000);
    }

    return PACKAGE32(_rxdata[0], _rxdata[1], _rxdata[2], _rxdata[3]);
    // uint16_t _outrxdata = (0xFF000000 & (_rxdata[0] << 24)) || (0x00FF0000 & (_rxdata[1] << 16)) || (0x0000FF00 & (_rxdata[2] << 8)) || (0x000000FF & (_txdata[3]));
    // return _outrxdata;
#else
    if (_inTransaction)
    {
        return spiTransferLongNL(_spi, data);
    }
    return spiTransferLong(_spi, data);
#endif
}
#endif

#if 0
void SPIClass::transferBits(uint32_t data, uint32_t *out, uint8_t bits)
{
#if 1

#else
    if (_inTransaction)
    {
        return spiTransferBitsNL(_spi, data, out, bits);
    }
    spiTransferBits(_spi, data, out, bits);
#endif
}
#endif

/**
 * @param data uint8_t *
 * @param size uint32_t
 */
void SPIClass::writeBytes(uint8_t *data, uint32_t size)
{
#if 1
    if (_spi_num == VSPI)
    {
        // HAL_SSI_Transmit_FAST(_ssi, (uint8_t *)data, size);
        HAL_SSI_Transmit(_ssi, (uint8_t *)data, size);
    }
    else
    {
        HAL_SPI_Transmit_FAST(_spi, (uint8_t *)data, size);
        // HAL_SPI_Transmit(_spi, (uint8_t*)data, size, 10000);
        // HAL_SPI_Transmit_IT(_spi, (uint8_t*)data, size);
        // HAL_SPI_Transmit_DMA(_spi, (uint8_t*)data, size);
    }
#else
    if (_inTransaction)
    {
        return spiWriteNL(_spi, data, size);
    }
    spiSimpleTransaction(_spi);
    spiWriteNL(_spi, data, size);
    spiEndTransaction(_spi);
#endif
}


void SPIClass::transfer(uint8_t *data, uint32_t size)
{
    transferBytes(data, data, size);
}

/**
 * @param data void *
 * @param size uint32_t
 */

void SPIClass::writePixels(const void *data_in, uint32_t size)
{
    uint8_t _buffer[size*2] = {0};
    uint8_t * data = (uint8_t*)data_in;

    // for (uint32_t i = 0; i < (size / 2); i++)
    // {
    //     uint32_t _offset = i * 2;
    //     _buffer[_offset] = data[_offset + 1];
    //     _buffer[_offset + 1] = data[_offset];
    // }

    for (uint32_t i = 0; i < size; i++)
    {
        if((i % 2) == 0)
            _buffer[i] = data[i + 1];
        else
            _buffer[i] = data[i - 1];
    }
    
    if (_spi_num == VSPI)
    {
        // HAL_SSI_Transmit_FAST(_ssi, (uint8_t *)_buffer, size);
        HAL_SSI_Transmit(_ssi, (uint8_t *)_buffer, size);
    }
    else
    {
        HAL_SPI_Transmit_FAST(_spi, (uint8_t *)_buffer, size);
        // HAL_SPI_Transmit(_spi, (uint8_t*)_buffer, size, 10000);
    }
}


/**
 * @param data uint8_t * data buffer. can be NULL for Read Only operation
 * @param out  uint8_t * output buffer. can be NULL for Write Only operation
 * @param size uint32_t
 */
void SPIClass::transferBytes(uint8_t *data, uint8_t *out, uint32_t size)
{
#if 1
    if (_spi_num == VSPI)
    {
        HAL_SSI_TransmitReceive(_ssi, (uint8_t *)data, (uint8_t *)out, size);
    }
    else
    {
        HAL_SPI_TransmitReceive(_spi, (uint8_t *)data, (uint8_t *)out, size, 10000);
    }
#else
    if (_inTransaction)
    {
        return spiTransferBytesNL(_spi, data, out, size);
    }
    spiTransferBytes(_spi, data, out, size);
#endif
}



SPIClass SPI(HSPI);
SPIClass SSI(VSPI);
