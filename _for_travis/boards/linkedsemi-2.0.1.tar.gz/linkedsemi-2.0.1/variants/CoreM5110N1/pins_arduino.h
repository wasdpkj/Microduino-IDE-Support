#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <string.h>
#include <stdint.h>
#include "arduino_config.h"

#include "pgmspace.h"
#include "ls_soc_gpio.h"


#ifdef __cplusplus
extern "C"{
#endif


#define EXTERNAL_NUM_INTERRUPTS 16

#define digitalPinToInterrupt(p)    (((p)<0x40)?(p):-1)

#define MAX_GPIO_NUM  0x3F

#define TEMP  0x79
#define VBAT  0x7A
#define analogPinToChannel(p)   (((p) == PB12) ? 0 : \
                                 ((p) == PB13) ? 1 : \
                                 ((p) == PC00) ? 2 : \
                                 ((p) == PC01) ? 3 : \
                                 ((p) == PA00) ? 4 : \
                                 ((p) == PA01) ? 5 : \
                                 ((p) == PA02) ? 6 : \
                                 ((p) == PA03) ? 7 : \
                                 ((p) == PA04) ? 8 : \
                                 ((p) == TEMP) ? 9 : \
                                 ((p) == VBAT) ? 10 : \
                                 -1)  


#define D0      PB01
#define D1      PB00
#define D2      PB15
#define D3      PB11
#define D4      PA12
#define D5      PA13
#define D6      PA14
#define D7      PB10
#define D8      PB09
#define D9      PB14
#define D10     PC01
#define D11     PA08
#define D12     PA09
#define D13     PA06

#define A0      PB12
#define A1      PB13
#define A2      PA00
#define A3      PA01
#define A4      PA02
#define A5      PA03
#define A6      PA04
#define A7      PC00

#define BOOT    PB14
#define D14     A0
#define D15     A1
#define D16     A2
#define D17     A3
#define D18     A4
#define D19     A5
#define D20     A6
#define D21     A7

#define SWD     PB05
#define SWC     PB06

#define PIN_SWD SWD
#define PIN_SWC SWC

#define SDA     A4
#define SCL     A5

#define SCK     D13
#define MOSI    D11
#define MISO    D12
#define SS      D10

#define RFID_CS PA05
#define RFID_IRQ PA07

#define PIN_RXD0    PB01
#define PIN_TXD0    PB00

#define LED_BUILTIN PB02

#ifdef __cplusplus
}; // extern "C"
#endif

#endif
