
#ifndef LS_ARDUINO_CONFIG_H_
#define LS_ARDUINO_CONFIG_H_

#ifndef SDK_DEEP_SLEEP_ENABLE
#define SDK_DEEP_SLEEP_ENABLE 0
#endif


#include "sdk_config.h"


#endif
