#ifndef MAIN_LE501X_HAL_ADC_H_
#define MAIN_LE501X_HAL_ADC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "ls_hal_adc.h"


#define ADC_HW_BIT      12
#define ADCBITS_MIN     6

#if (SDK_HCLK_MHZ == 16)
#define ADC_CLOCK_DIV_NORMAL    ADC_CLOCK_DIV4
#elif (SDK_HCLK_MHZ == 32)
#define ADC_CLOCK_DIV_NORMAL    ADC_CLOCK_DIV8
#else
#define ADC_CLOCK_DIV_NORMAL    ADC_CLOCK_DIV16
#endif

#define ADC_SAMPLETIME_NORMAL   ADC_SAMPLETIME_1CYCLE   //1/2/4/15 sample

/** 
 * @defgroup ADC_sampling_times ADC sampling times
*/
// #define ADC_SAMPLETIME_1CYCLE   0x00000000U                 /*!< Sampling time 1 ADC clock cycle */
// #define ADC_SAMPLETIME_2CYCLES  0x00000001U                 /*!< Sampling time 2 ADC clock cycles */
// #define ADC_SAMPLETIME_4CYCLES  0x00000002U                 /*!< Sampling time 4 ADC clock cycles */
// #define ADC_SAMPLETIME_15CYCLES 0x00000003U                 /*!< Sampling time 15 ADC clock cycles */

/** 
 *  @defgroup ADC_Clock_Division ADC Clock Division
*/       
// #define ADC_CLOCK_DIV2          0x00000001U                 
// #define ADC_CLOCK_DIV4          0x00000002U                 
// #define ADC_CLOCK_DIV8          0x00000003U                 
// #define ADC_CLOCK_DIV16         0x00000004U               
// #define ADC_CLOCK_DIV32         0x00000005U                 
// #define ADC_CLOCK_DIV64         0x00000006U                 
// #define ADC_CLOCK_DIV128        0x00000007U  

/*
 * Get ADC value for pin
 * */
uint16_t analogRead(uint8_t pin);

HAL_StatusTypeDef analogReference(uint8_t mode);

/*
 * Set the resolution of analogRead return values. Default is 12 bits (range from 0 to 4095).
 * If between 6 and 12, it will equal the set hardware resolution, else value will be shifted.
 * Range is 1 - 16
 *
 * Note: compatibility with Arduino SAM
 */
void analogReadResolution(uint8_t bits);

/*
 * Sets the sample bits and read resolution
 * Default is 12bit (0 - 4095)
 * Range is 6 - 12
 * */
void analogSetWidth(uint8_t bits);


/*
 * Set number of samples in the range.
 * Default is 1
 * Range is 1 / 2 / 4 / 15
 * This setting splits the range into
 * "samples" pieces, which could look
 * like the sensitivity has been multiplied
 * that many times
 * */
void analogSetSamples(uint8_t samples);

/*
 * Set the divider for the ADC clock.
 * Default is 1
 * Range is 2 - 128
 * */
void analogSetClockDiv(uint8_t clockDiv);


/*
 * Get value for vbat
 * */
uint16_t vbatRead();

/*
 * Non-Blocking API (almost)
 *
 * Note: ADC conversion can run only for single pin at a time.
 *       That means that if you want to run ADC on two pins on the same bus,
 *       you need to run them one after another. Probably the best use would be
 *       to start conversion on both buses in parallel.
 * */

/*
 * Attach pin to ADC (will also clear any other analog mode that could be on)
 * */
bool adcAttachPin(uint8_t pin);

/*
 * DeAttach pin to ADC (will also clear any other analog mode that could be on)
 * */
bool adcDeAttachPin(uint8_t pin);

/*
 * Start ADC conversion on attached pin's bus
 * */
bool adcStart(uint8_t pin);

/*
 * Check if conversion on the pin's ADC bus is currently running
 * */
bool adcBusy(uint8_t pin);

/*
 * Get the result of the conversion (will wait if it have not finished)
 * */
uint32_t adcEnd(uint8_t pin);

#ifdef __cplusplus
}
#endif

#endif /* MAIN_LE501X_HAL_ADC_H_ */
