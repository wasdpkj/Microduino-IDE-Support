#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>

#include "wiring_private.h"
#include "HardwareSerial.h"


#undef LOG_TAG
#define LOG_TAG "HWSERIAL"


#if !defined(NO_GLOBAL_INSTANCES) && !defined(NO_GLOBAL_SERIAL)
UART_HandleTypeDef UART3_Config;
HardwareSerial Serial(3);
#if defined(HAVE_HWSERIAL1)
UART_HandleTypeDef UART1_Config;
HardwareSerial Serial1(1);
#endif
#if defined(HAVE_HWSERIAL2)
UART_HandleTypeDef UART2_Config;
HardwareSerial Serial2(2);
#endif
#endif


// SerialEvent functions are weak, so when the user doesn't define them,
// the linker just sets their address to 0 (which is checked below).
// The Serialx_available is just a wrapper around Serialx.available(),
// but we can refer to it weakly so we don't pull in the entire
// HardwareSerial instance if the user doesn't also refer to it.
  void serialEvent() __attribute__((weak));
  bool Serial0_available() __attribute__((weak));

#if defined(HAVE_HWSERIAL1)
  void serialEvent1() __attribute__((weak));
  bool Serial1_available() __attribute__((weak));
#endif

#if defined(HAVE_HWSERIAL2)
  void serialEvent2() __attribute__((weak));
  bool Serial2_available() __attribute__((weak));
#endif


void serialEventRun(void)
{
  if (Serial0_available && serialEvent && Serial0_available()) serialEvent();
#if defined(HAVE_HWSERIAL1)
  if (Serial1_available && serialEvent1 && Serial1_available()) serialEvent1();
#endif
#if defined(HAVE_HWSERIAL2)
  if (Serial2_available && serialEvent2 && Serial2_available()) serialEvent2();
#endif
}

uint16_t transfor_baud(unsigned long baud)
{
    return UART_BUADRATE_ENUM_GEN(baud);
}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    // LOG_RAW("HAL_UART_RxCpltCallback\r\n");

    if (huart == &UART3_Config)
    {
        Serial._rx_complete_irq();
    }
#if defined(HAVE_HWSERIAL1)    
    else if (huart == &UART1_Config)
    {
        Serial1._rx_complete_irq();
    }
#endif
#if defined(HAVE_HWSERIAL2)    
    else if (huart == &UART2_Config)
    {
        Serial2._rx_complete_irq();
    }
#endif
}

#if 0
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &UART3_Config)
    {
        Serial._tx_udr_empty_irq();
    }
#if defined(HAVE_HWSERIAL1)    
    else if (huart == &UART1_Config)
    {
        Serial1._tx_udr_empty_irq();
    }
#endif
#if defined(HAVE_HWSERIAL2)
    else if (huart == &UART2_Config)
    {
        Serial2._tx_udr_empty_irq();
    }
#endif
}
#endif


HardwareSerial::HardwareSerial(int uart_nr) : _uart_nr(uart_nr), _uart(NULL) {}


void HardwareSerial::_rx_complete_irq(void)
{
    // at_recv(at_recv_char);
    unsigned char c = _rx_byte;

    rx_buffer_index_t i = (unsigned int)(_rx_buffer_head + 1) % SERIAL_RX_BUFFER_SIZE;

    // if we should be storing the received character into the location
    // just before the tail (meaning that the head would advance to the
    // current location of the tail), we're about to overflow the buffer
    // and so we don't write the character or advance the head.
    if (i != _rx_buffer_tail)
    {
        _rx_buffer[_rx_buffer_head] = c;
        _rx_buffer_head = i;
    }

    HAL_UART_Receive_IT(_uart, &_rx_byte, 1);
}

void HardwareSerial::_tx_udr_empty_irq(void)
{
#if 0
    // If interrupts are enabled, there must be more data in the output
    // buffer. Send the next byte
    unsigned char c = _tx_buffer[_tx_buffer_tail];
    _tx_buffer_tail = (_tx_buffer_tail + 1) % SERIAL_TX_BUFFER_SIZE;

    //   *_udr = c;
    HAL_UART_Transmit_IT(_uart, (uint8_t *)c, 1);
    // clear the TXC bit -- "can be cleared by writing a one to its bit
    // location". This makes sure flush() won't return until the bytes
    // actually got written. Other r/w bits are preserved, and zeroes
    // written to the rest.

    if (_tx_buffer_head == _tx_buffer_tail)
    {
        // Buffer empty, so disable interrupts
        // cbi(*_ucsrb, UDRIE0);
    }
#endif
}

void HardwareSerial::begin(unsigned long baud, uint32_t config, int8_t rxPin, int8_t txPin, bool invert, unsigned long timeout_ms)
{   
    if (_uart_nr == 3)
    {
        _uart = &UART3_Config;
        _uart->UARTX = UART3;
        pinmux_uart3_init(txPin, rxPin);
    }
#if defined(HAVE_HWSERIAL1)
    else if (_uart_nr == 1)
    {
        _uart = &UART1_Config;
        _uart->UARTX = UART1;
        pinmux_uart1_init(txPin, rxPin);
    }
#endif
#if defined(HAVE_HWSERIAL2)
    else if (_uart_nr == 2)
    {
        _uart = &UART2_Config;
        _uart->UARTX = UART2;
        pinmux_uart2_init(txPin, rxPin);
    }
#endif
    else
    {
        LOG_RAW("Serial number is invalid, please use 1, 2 or 3\r\n");
        return;
    }

    serialTimeout = timeout_ms;

    _uart->Init.BaudRate = (app_uart_baudrate_t)transfor_baud(baud);

    _uart->Init.WordLength = 0x03 & (config >> 5);
    _uart->Init.StopBits = 0x01 & (config >> 4);
    _uart->Init.Parity = 0x03 & (config >> 2);

    if (invert)
    {
        _uart->Init.MSBEN = 1;
    }
    else
    {
        _uart->Init.MSBEN = 0;
    }
    _uart->Init.HwFlowCtl = 0;

    HAL_UART_Init(_uart);
    HAL_UART_Receive_IT(_uart, &_rx_byte, 1);

    _written = false;
}

void HardwareSerial::end()
{
#if 1
    // wait for transmission of outgoing data
    flush();

    _rx_buffer_head = _rx_buffer_tail;
    _uart = 0;
#else
    if (uartGetDebug() == _uart_nr)
    {
        uartSetDebug(0);
    }
    uartEnd(_uart);
    _uart = 0;
#endif
}

int HardwareSerial::available(void)
{
    return ((unsigned int)(SERIAL_RX_BUFFER_SIZE + _rx_buffer_head - _rx_buffer_tail)) % SERIAL_RX_BUFFER_SIZE;
    // return uartAvailable(_uart);
}

int HardwareSerial::availableForWrite(void)
{
    tx_buffer_index_t head;
    tx_buffer_index_t tail;

    head = _tx_buffer_head;
    tail = _tx_buffer_tail;

    if (head >= tail)
        return SERIAL_TX_BUFFER_SIZE - 1 - head + tail;
    return tail - head - 1;
    // return uartAvailableForWrite(_uart);
}

int HardwareSerial::peek(void)
{
    if (_rx_buffer_head == _rx_buffer_tail)
    {
        return -1;
    }
    else
    {
        return _rx_buffer[_rx_buffer_tail];
    }
}

int HardwareSerial::read(void)
{
    // if the head isn't ahead of the tail, we don't have any characters
    if (_rx_buffer_head == _rx_buffer_tail)
    {
        return -1;
    }
    else
    {
        unsigned char c = _rx_buffer[_rx_buffer_tail];
        _rx_buffer_tail = (rx_buffer_index_t)(_rx_buffer_tail + 1) % SERIAL_RX_BUFFER_SIZE;
        return c;
    }
}

void HardwareSerial::flush()
{
    // If we have never written a byte, no need to flush. This special
    // case is needed since there is no way to force the TXC (transmit
    // complete) bit to 1 during initialization
    if (!_written)
        return;
}

size_t HardwareSerial::write(uint8_t c)
{
#if 0
    _written = true;
    // If the buffer and the data register is empty, just write the byte
    // to the data register and be done. This shortcut helps
    // significantly improve the effective datarate at high (>
    // 500kbit/s) bitrates, where interrupt overhead becomes a slowdown.
    // if (_tx_buffer_head == _tx_buffer_tail && (_uart->gState == HAL_UART_STATE_READY))
    if (_tx_buffer_head == _tx_buffer_tail)
    {
        // If TXC is cleared before writing UDR and the previous byte
        // completes before writing to UDR, TXC will be set but a byte
        // is still being transmitted causing flush() to return too soon.
        // So writing UDR must happen first.
        // Writing UDR and clearing TC must be done atomically, otherwise
        // interrupts might delay the TXC clear so the byte written to UDR
        // is transmitted (setting TXC) before clearing TXC. Then TXC will
        // be cleared when no bytes are left, causing flush() to hang
        HAL_UART_Transmit_IT(_uart, (uint8_t *)c, 1);
    }

    tx_buffer_index_t i = (_tx_buffer_head + 1) % SERIAL_TX_BUFFER_SIZE;

    // If the output buffer is full, there's nothing for it other than to
    // wait for the interrupt handler to empty it a bit
    while (i == _tx_buffer_tail)
    {
        _tx_udr_empty_irq();
    }

    _tx_buffer[_tx_buffer_head] = c;

    _tx_buffer_head = i;

    return 1;
#else
    _written = true;

    // uint8_t _buffer[1];
    // _buffer[0] = c;

    // HAL_UART_Transmit(_uart, _buffer, 1, serialTimeout);
    HAL_UART_Transmit(_uart, (uint8_t*)&c, 1, serialTimeout);

    return 1;
#endif
}

size_t HardwareSerial::write(const uint8_t *buffer, size_t size)
{
    _written = true;

    uint8_t *data = (uint8_t*)buffer;

    HAL_UART_Transmit(_uart, data, size, serialTimeout);

    return size;
}

size_t HardwareSerial::write(uint8_t *buffer, size_t size)
{
    _written = true;

    HAL_UART_Transmit(_uart, buffer, size, serialTimeout);

    return size;
}

HardwareSerial::operator bool() const
{
    return true;
}
