#include <string.h>
#include <stdlib.h>

#include "le501x-hal-gpio.h"


const uint32_t port_addr[MAX_GPIO_NUM/16] = {(uint32_t)LSGPIOA, (uint32_t)LSGPIOB, (uint32_t)LSGPIOC};

#ifdef FASTIO_USER_UNION
union gpio_info gpio[MAX_GPIO_NUM];
#else
reg_gpio_t gpio[MAX_GPIO_NUM];
#endif

void pinMode(uint8_t pin, uint8_t mode)
{
	if (pin > MAX_GPIO_NUM)
	{
		return;
	}

#ifdef FASTIO_USER_UNION
	gpio[pin].pin = pin;
	// gpio[pin].b.num = pin & 0x0F;
	// gpio[pin].b.port = (pin >> 4) & 0x0F;
#else
	gpio[pin].num = pin & 0x0F;
	gpio[pin].port = (pin >> 4) & 0x0F;
#endif

	if (mode == OUTPUT)
	{
		gpio_ana_deinit(pin);
		io_cfg_pushpull(pin);
		io_cfg_output(pin);
		/*
			IO_OUTPUT_QUARTER_DRIVER	0	? 2/0
			IO_OUTPUT_HALF_DRIVER		2	? 1
			IO_OUTPUT_MAX_DRIVER		3	? 3
		*/
		io_drive_capacity_write(pin, 2);
	}
	else if (mode == OUTPUT_OD)
	{
		gpio_ana_deinit(pin);
		io_cfg_opendrain(pin);
		io_cfg_output(pin);
		/*
			IO_OUTPUT_QUARTER_DRIVER	0	? 2/0
			IO_OUTPUT_HALF_DRIVER		2	? 1
			IO_OUTPUT_MAX_DRIVER		3	? 3
		*/
		io_drive_capacity_write(pin, 2);
	}
	else if (mode == INPUT)
	{
		gpio_ana_deinit(pin);
		io_cfg_input(pin);
		io_pull_write(pin, IO_PULL_DISABLE);
	}
	else if (mode == INPUT_PULLUP)
	{
		gpio_ana_deinit(pin);
		io_cfg_input(pin);
		io_pull_write(pin, IO_PULL_UP);
	}
	else if (mode == INPUT_PULLDOWN)
	{
		gpio_ana_deinit(pin);
		io_cfg_input(pin);
		io_pull_write(pin, IO_PULL_DOWN);
	}
	else if (mode == ANALOG)
	{
		pinmux_ana_func1_init(pin);
	}
	else
	{

	}
}

void digitalWrite(uint8_t pin, uint8_t val)
{
#if 1
	if (pin > MAX_GPIO_NUM)
	{
		return;
	}

	if (val)
	{
		io_set_pin(pin);
	}
	else
	{
		io_clr_pin(pin);
	}
#else
	io_write_pin(pin, val);
#endif
}

int digitalRead(uint8_t pin)
{
#if 1
	if (pin > MAX_GPIO_NUM)
	{
		return 0;
	}
	
	gpio_pin_t *x = (gpio_pin_t *)&pin;
	reg_lsgpio_t *gpiox = GPIO_GetPort(x->port);
	uint8_t val = (gpiox->DIN >> x->num) & 0x1;
	return val;
#else
	uint8_t port = io_read_pin(pin);

	if (port)
		return 1;
	return 0;
#endif
}
