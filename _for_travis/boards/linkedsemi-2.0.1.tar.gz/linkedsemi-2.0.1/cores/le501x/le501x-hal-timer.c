#include <stdlib.h>
#include <stdbool.h>

#include "le501x-hal-timer.h"
#include "platform.h"
#include "ls_soc_gpio.h"


/* ---------------hardware timer--------------- */
typedef void (*voidFuncPtr)(void);
static voidFuncPtr __hwTimerInterruptFunc[MAX_TIMER] = {0,0,0,0};

void XIP_BANNED_FUNC(_arduino_timerISR, TIM_HandleTypeDef *htim)
{
    // LOG_RAW("%d\r\n", 10);

    if(__hwTimerInterruptFunc[TIMER_0] && (htim->Instance == LSGPTIMA))
    {
        __hwTimerInterruptFunc[TIMER_0]();
    }
    else if(__hwTimerInterruptFunc[TIMER_1] && (htim->Instance == LSGPTIMB))
    {
        __hwTimerInterruptFunc[TIMER_1]();
    }
    else if(__hwTimerInterruptFunc[TIMER_2] && (htim->Instance == LSGPTIMC))
    {
        __hwTimerInterruptFunc[TIMER_2]();
    }
    else if(__hwTimerInterruptFunc[TIMER_3] && (htim->Instance == LSADTIM))
    {
        __hwTimerInterruptFunc[TIMER_3]();
    }
}


void timerAttachInterrupt(TIM_HandleTypeDef *timer, void (*fn)(void))
{
    static bool initialized = false;
    static uint8_t _num = 0;
    
    if(timer->Instance == LSADTIM)
    {
        _num = TIMER_3;
        // LOG_RAW("TIMER=3\r\n");
    }
    else if(timer->Instance == LSGPTIMC)
    {
        _num = TIMER_2;
        // LOG_RAW("TIMER=2\r\n");
    }
    else if(timer->Instance == LSGPTIMB)
    {
        _num = TIMER_1;
        // LOG_RAW("TIMER=1\r\n");
    }
    else
    {
        _num = TIMER_0;
        // LOG_RAW("TIMER=0\r\n");
    }

    if(fn == NULL)
    {
        __hwTimerInterruptFunc[_num] = NULL;
    }
    else 
    {
        __hwTimerInterruptFunc[_num] = fn;

        HAL_TIM_Init(timer);
        HAL_TIM_Base_Start_IT(timer);

        if(!initialized){
            initialized = true;
        
        }
        else 
        {
        
        }
    }

}


void timerDetachInterrupt(TIM_HandleTypeDef *timer)
{
    timerAttachInterrupt(timer, NULL);

    HAL_TIM_Base_Stop_IT(timer);
    HAL_TIM_DeInit(timer);
}


/* ---------------software timer--------------- */
static uint32_t softTimerPeriod = 0;
static bool softTimerinitialized = false;

typedef void (*voidFuncSoftTimerPtr)(void);
static voidFuncSoftTimerPtr __swTimerInterruptFunc[SOFTTIMER_MAXCHANNELS] = {0,0,0,0,0,0,0,0};


SW_TIM_HandleTypeDef _swTimHandles[SOFTTIMER_MAXCHANNELS];

static TIM_HandleTypeDef _sourceTimHandle;

void XIP_BANNED_FUNC(softTimerISR, void)
{
  // If the channel isn't already set, add it
  for (uint8_t i = 0; i < SOFTTIMER_MAXCHANNELS; i++)
  {
    if(__swTimerInterruptFunc[i])
    {
        _swTimHandles[i].periodCalc += softTimerPeriod;
        if(_swTimHandles[i].periodCalc >= _swTimHandles[i].period)
        {
            _swTimHandles[i].periodCalc = 0;
            __swTimerInterruptFunc[i]();
        }
        
    }
  }
}


void softTimerInit(SW_TIM_HandleTypeDef *_handle)
{
    if(_handle->init.period <= 0)
    {
        _handle->init.period = DEFAULT_SWTIM_PERIOD;
    }
    softTimerPeriod = _handle->init.period;

    switch(_handle->init.timer)
    {
        case TIMER_3:
            _sourceTimHandle.Instance       = LSADTIM;
            break;
        case TIMER_2:
            _sourceTimHandle.Instance       = LSGPTIMC;
            break;
        case TIMER_1:
            _sourceTimHandle.Instance       = LSGPTIMB;
            break;
        case TIMER_0:
            _sourceTimHandle.Instance       = LSGPTIMA;
            break;
        default:
            _sourceTimHandle.Instance       = LSGPTIMA;
    }


    _sourceTimHandle.Init.Prescaler     = SOFTTIM_PRESCALER;
    _sourceTimHandle.Init.Period        = softTimerPeriod - 1;
    _sourceTimHandle.Init.ClockDivision = 0;
    _sourceTimHandle.Init.CounterMode   = TIM_COUNTERMODE_UP;

    // LOG_RAW("Prescaler = %d, Period = %d\r\n", _sourceTimHandle.Init.Prescaler, _sourceTimHandle.Init.Period);

	timerAttachInterrupt(&_sourceTimHandle, softTimerISR);

    softTimerinitialized = true;
}

void softTimerDeinit()
{
    timerDetachInterrupt(&_sourceTimHandle);
    softTimerinitialized = false;
}

void softTimerAttachInterrupt(SW_TIM_HandleTypeDef *swtimer, void (*fn)(void))
{
//   LOG_RAW("softTimerAttachInterrupt\r\n");
  int8_t firstfree = -1;  // first free index

  if(!softTimerinitialized)
  {
    for (uint8_t i = 0; i < SOFTTIMER_MAXCHANNELS; i++)
    {
      _swTimHandles[i].channel = -1;
      _swTimHandles[i].periodCalc = 0;
      _swTimHandles[i].number = -1;
    }
  }

  if(swtimer->period <= 0)
  {
    swtimer->period = DEFAULT_SWTIM_PERIOD;
  }

  // If the channel isn't already set, add it
  for (uint8_t i = 0; i < SOFTTIMER_MAXCHANNELS; i++)
  {
    if ((swtimer->channel < 0 && _swTimHandles[i].channel >= 0) ||  // ALL channels
       (swtimer->channel >= 0 && _swTimHandles[i].channel == swtimer->channel))  // individual channel
    {
      // set the channel (and exit, if individual channel)
      _swTimHandles[i].period = swtimer->period;

      if (swtimer->channel >= 0) // we've set the individual channel
      {
        return;
      }
    }

    // get the first free channel if available
    if (firstfree < 0 && _swTimHandles[i].channel < 0)
    {
      firstfree = i;
    }
  }

  if (swtimer->channel >= 0 && firstfree >= 0)
  {
    // we have a free channel we can use
    _swTimHandles[firstfree].channel = swtimer->channel;
    _swTimHandles[firstfree].period = swtimer->period;
    
    if(fn == NULL)
    {
        // LOG_RAW("__swTimerInterruptFunc[firstfree] = NULL\r\n");
        __swTimerInterruptFunc[firstfree] = NULL;
        _swTimHandles[firstfree].number = -1;
    }
    else 
    {
        // LOG_RAW("__swTimerInterruptFunc[firstfree] = fn\r\n");
        __swTimerInterruptFunc[firstfree] = fn;
        _swTimHandles[firstfree].number = firstfree;

        if(!softTimerinitialized)
        {
            softTimerinitialized = true;

            // LOG_RAW("softTimerInit\r\n");
            softTimerInit(swtimer);
        }
        else
        {

        }
    }

  }
}


void softTimerDetachInterrupt(SW_TIM_HandleTypeDef *swtimer)
{
    if(swtimer->channel >= 0)
    {
        if(swtimer->number >= 0)
        {
            if(__swTimerInterruptFunc[swtimer->number])
            {
                __swTimerInterruptFunc[swtimer->number] = NULL;
            }
        }
        swtimer->channel = -1;
        swtimer->period = 0;
        swtimer->periodCalc = 0;
        swtimer->number = -1;
    }

    bool _hasSoftTimer = 0;
    for (uint8_t i = 0; i < SOFTTIMER_MAXCHANNELS; i++)
    {
        if(_swTimHandles[i].channel >= 0)
        {
            _hasSoftTimer = 1;
            break;
        }
    }

    if(_hasSoftTimer == 0)
    {
        softTimerDeinit();
    }
}


/* ---------------hardware timer pwm--------------- */
static TIM_OC_InitTypeDef sConfig = {0};
static uint32_t pwmChannel[HW_PWM_CHANNEL] = {TIM_CHANNEL_1, TIM_CHANNEL_2, TIM_CHANNEL_3, TIM_CHANNEL_4};
static TIM_HandleTypeDef pwmTimHandle;

typedef void (*voidFuncChannelInitPtr)(uint8_t pin,bool output,uint8_t default_val);
static voidFuncChannelInitPtr __pwmIoInitFunc[4] = {0,0,0,0};

typedef void (*voidFuncChannelDenitPtr)(void);
static voidFuncChannelDenitPtr __pwmIoDeinitFunc[4] = {0,0,0,0};

void XIP_BANNED_FUNC(pwmTimerISR, void)
{
  // If the channel isn't already set, add it
    // LOG_RAW("pwmTimerISR\r\n");
}

static uint8_t _pwmMaxNbr = 0;
uint8_t pwmMaxNbr(void)
{
    return _pwmMaxNbr;
}

void pwmInit(uint8_t _timer, uint32_t _period)
{
    if(_timer == 0)
    {
        pwmTimHandle.Instance = LSGPTIMA;
        _pwmMaxNbr = 4;
        __pwmIoInitFunc[0] = pinmux_gptima1_ch1_init;
        __pwmIoInitFunc[1] = pinmux_gptima1_ch2_init;
        __pwmIoInitFunc[2] = pinmux_gptima1_ch3_init;
        __pwmIoInitFunc[3] = pinmux_gptima1_ch4_init;
        __pwmIoDeinitFunc[0] = pinmux_gptima1_ch1_deinit;
        __pwmIoDeinitFunc[1] = pinmux_gptima1_ch2_deinit;
        __pwmIoDeinitFunc[2] = pinmux_gptima1_ch3_deinit;
        __pwmIoDeinitFunc[3] = pinmux_gptima1_ch4_deinit;
    }
    else if(_timer == 1)
    {
        pwmTimHandle.Instance = LSGPTIMB;
        _pwmMaxNbr = 4;
        __pwmIoInitFunc[0] = pinmux_gptimb1_ch1_init;
        __pwmIoInitFunc[1] = pinmux_gptimb1_ch2_init;
        __pwmIoInitFunc[2] = pinmux_gptimb1_ch3_init;
        __pwmIoInitFunc[3] = pinmux_gptimb1_ch4_init;
        __pwmIoDeinitFunc[0] = pinmux_gptimb1_ch1_deinit;
        __pwmIoDeinitFunc[1] = pinmux_gptimb1_ch2_deinit;
        __pwmIoDeinitFunc[2] = pinmux_gptimb1_ch3_deinit;
        __pwmIoDeinitFunc[3] = pinmux_gptimb1_ch4_deinit;
    }
    else if(_timer == 2)
    {
        pwmTimHandle.Instance = LSGPTIMC;
        _pwmMaxNbr = 2;
        __pwmIoInitFunc[0] = pinmux_gptimc1_ch1_init;
        __pwmIoInitFunc[1] = pinmux_gptimc1_ch2_init;
        __pwmIoDeinitFunc[0] = pinmux_gptimc1_ch1_deinit;
        __pwmIoDeinitFunc[1] = pinmux_gptimc1_ch2_deinit;
    }
    else if(_timer == 3)
    {
        pwmTimHandle.Instance = LSADTIM;
        _pwmMaxNbr = 4;
        __pwmIoInitFunc[0] = pinmux_adtim1_ch1_init;
        __pwmIoInitFunc[1] = pinmux_adtim1_ch2_init;
        __pwmIoInitFunc[2] = pinmux_adtim1_ch3_init;
        __pwmIoInitFunc[3] = pinmux_adtim1_ch4_init;
        __pwmIoDeinitFunc[0] = pinmux_adtim1_ch1_deinit;
        __pwmIoDeinitFunc[1] = pinmux_adtim1_ch2_deinit;
        __pwmIoDeinitFunc[2] = pinmux_adtim1_ch3_deinit;
        __pwmIoDeinitFunc[3] = pinmux_adtim1_ch4_deinit;   
    }

    pwmTimHandle.Init.Prescaler = HARDTIM_PRESCALER; 
    pwmTimHandle.Init.Period = _period;
    pwmTimHandle.Init.ClockDivision = 0;
    pwmTimHandle.Init.CounterMode = TIM_COUNTERMODE_UP;
    pwmTimHandle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
        
    // HAL_TIM_Init(&pwmTimHandle);

    timerAttachInterrupt(&pwmTimHandle, pwmTimerISR);
}

void pwmDeinit(void)
{
    __pwmIoInitFunc[0] = NULL;
    __pwmIoInitFunc[1] = NULL;
    __pwmIoInitFunc[2] = NULL;
    __pwmIoInitFunc[3] = NULL;
    __pwmIoDeinitFunc[0] = NULL;
    __pwmIoDeinitFunc[1] = NULL;
    __pwmIoDeinitFunc[2] = NULL;
    __pwmIoDeinitFunc[3] = NULL;
    timerDetachInterrupt(&pwmTimHandle);
}


void pwmAttachPin(uint8_t _pin, uint8_t _channel)
{
    // if(_channel > ((sizeof(pwmChannel)/sizeof(uint32_t)) - 1))
    if(_channel > (HW_PWM_CHANNEL - 1))
    {
        return;
    }
    

    if(__pwmIoInitFunc[_channel])
    {
        __pwmIoInitFunc[_channel](_pin, true, 0);
    }


    sConfig.OCMode = TIM_OCMODE_PWM1;
    sConfig.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfig.OCFastMode = TIM_OCFAST_DISABLE;
    sConfig.Pulse = 0;

    HAL_TIM_PWM_ConfigChannel(&pwmTimHandle, &sConfig, pwmChannel[_channel]);    
    HAL_TIM_PWM_Start(&pwmTimHandle, pwmChannel[_channel]);
}

void pwmDetachPin(uint8_t _channel)
{
    if(__pwmIoDeinitFunc[_channel])
    {
        __pwmIoDeinitFunc[_channel]();
    }

    HAL_TIM_PWM_Stop(&pwmTimHandle, pwmChannel[_channel]);    
}

void pwmUpdata(uint8_t _channel, uint32_t _pulse)
{
    sConfig.OCMode = TIM_OCMODE_PWM1;
    sConfig.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfig.OCFastMode = TIM_OCFAST_DISABLE;


    sConfig.Pulse = _pulse;
    HAL_TIM_PWM_ConfigChannel(&pwmTimHandle, &sConfig, pwmChannel[_channel]);    
    HAL_TIM_PWM_Start(&pwmTimHandle, pwmChannel[_channel]); 
}
