#ifndef MAIN_LE501X_HAL_GPIO_H_
#define MAIN_LE501X_HAL_GPIO_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "pins_arduino.h"
#include "ls_soc_gpio.h"
#include "reg_gpio.h"


#define INPUT           0x0
#define OUTPUT          0x1
#define INPUT_PULLUP    0x2
#define INPUT_PULLDOWN  0x3
#define OUTPUT_OD       0x4
#define ANALOG          0xA


#define FASTIO_USER_UNION	1

typedef struct {
	uint8_t pin;
	uint8_t num : 4,
			port : 4;
} fast_gpio_t;


extern const uint32_t port_addr[MAX_GPIO_NUM/16];

#ifdef FASTIO_USER_UNION
union gpio_info{
	struct{
		uint8_t num 	:4;
		uint8_t port	:4;
	}b;
	uint8_t pin;
};

extern union gpio_info gpio[MAX_GPIO_NUM];

#define PORTADDR(X)	((reg_lsgpio_t*)port_addr[gpio[X].b.port])

#define fastSetPin(X) {PORTADDR(X)->BSBR = 1<< gpio[X].b.num;}
#define fastClrPin(X) {PORTADDR(X)->BSBR = 1<< (gpio[X].b.num + 16);}
#define fastWritePin(X, Y) {if (Y){fastSetPin(X);}else{fastClrPin(X);}}
#define fastReadPin(X) ((PORTADDR(X)->DIN >> gpio[X].b.num) & 0x01)
#define fastTogglePin(X) {if (PORTADDR(X)->DOUT & 1<<gpio[X].b.num){fastClrPin(X);}else{fastSetPin(X);}}

#else
typedef struct {
	uint8_t num;
	uint8_t	port;
}reg_gpio_t;

extern reg_gpio_t gpio[MAX_GPIO_NUM];

#define PORTADDR(X)	((reg_lsgpio_t*)port_addr[gpio[X].port])

#define fastSetPin(X) {PORTADDR(X)->BSBR = 1<< gpio[X].num;}
#define fastClrPin(X) {PORTADDR(X)->BSBR = 1<< (gpio[X].num + 16);}
#define fastWritePin(X, Y) {if (Y){fastSetPin(X);}else{fastClrPin(X);}}
#define fastReadPin(X) ((PORTADDR(X)->DIN >> gpio[X].num) & 0x01)

#endif


// #define pinMode(X, Y)    {if(Y == OUTPUT) {io_cfg_output(X);} else if(Y == INPUT_PULLUP) {io_cfg_input(X);io_pull_write(X, IO_PULL_UP);}else {io_cfg_input(X);}}
// #define digitalWrite(X, Y)    io_write_pin(X, Y)
// #define digitalRead(X)        io_read_pin(X)

void pinMode(uint8_t, uint8_t);
void digitalWrite(uint8_t, uint8_t);
int digitalRead(uint8_t);


#ifdef __cplusplus
};
#endif

#endif