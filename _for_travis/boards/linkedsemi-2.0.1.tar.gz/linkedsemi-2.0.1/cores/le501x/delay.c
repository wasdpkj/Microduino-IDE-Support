#include "delay.h"


unsigned long millis()
{
	unsigned long m;

	m = systick_get_value();

	return m;
}


unsigned long micros()
{
	unsigned long m;

	m = systick_get_value() * 1000;
	return m;
}


void delay(unsigned long ms)
{
  if (ms == 0)
  {
    return ;
  }

  unsigned long _delayTick = millis();
  while(millis()-_delayTick <= (unsigned long)ms)
  {
    if(_delayTick > millis())
    {
      _delayTick = millis();
    } 
  }
  
}

void delayMicroseconds(unsigned long usec)
{
	DELAY_US(usec);
}
