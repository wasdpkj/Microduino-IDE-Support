/* -*- mode: jde; c-basic-offset: 2; indent-tabs-mode: nil -*- */

/*
  Part of the Wiring project - http://wiring.uniandes.edu.co

  Copyright (c) 2004-05 Hernando Barragan

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

  Modified 24 November 2006 by David A. Mellis
  Modified 1 August 2010 by Mark Sproul
*/

#include <inttypes.h>
#include <stdio.h>
#include "WInterrupts.h"

#include "pgmspace.h"
#include "ls_soc_pinmux.h"

#include "wiring_private.h"
#include "pins_arduino.h"

static void nothing(void)
{
}

static volatile voidFuncPtr intFunc[EXTERNAL_NUM_INTERRUPTS] = {
#if EXTERNAL_NUM_INTERRUPTS > 16
#error There are more than 16 external interrupts. Some callbacks may not be initialized.
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 15
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 14
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 13
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 12
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 11
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 10
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 9
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 8
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 7
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 6
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 5
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 4
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 3
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 2
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 1
    nothing,
#endif
#if EXTERNAL_NUM_INTERRUPTS > 0
    nothing,
#endif
};
// volatile static voidFuncPtr twiIntFunc;

void attachInterrupt(uint8_t interruptNum, void (*userFunc)(void), int mode)
{
  if (interruptNum > MAX_GPIO_NUM)
    return;

  // Enable the interrupt.
  intFunc[interruptNum & 0x0F] = userFunc;

  {
    io_cfg_input(interruptNum); // config input
    if (mode == FALLING)
    {
      // io_pull_write(interruptNum, IO_PULL_UP);        // config pullup
      io_exti_config(interruptNum, INT_EDGE_FALLING); // interrupt falling edge
    }
    else if (mode == RISING)
    {
      // io_pull_write(interruptNum, IO_PULL_DOWN);     // config pulldown
      io_exti_config(interruptNum, INT_EDGE_RISING); // interrupt rising edge
    }
    else if(mode == CHANGE)
    {
      io_exti_config(interruptNum, INT_EDGE_BOTH); // interrupt falling edge
    }
    else
    {
      io_exti_config(interruptNum, INT_EDGE_UNKNOWN);
    }
  }
}

void detachInterrupt(uint8_t interruptNum)
{
  if (interruptNum > MAX_GPIO_NUM)
    return;

  // Disable the interrupt.  (We can't assume that interruptNum is equal
  io_exti_config(interruptNum, INT_EDGE_DISABLE);

  intFunc[interruptNum & 0x0F] = nothing;
}


void _arduino_exti_callback(uint8_t pin, exti_edge_t edge)
{
  if (pin > MAX_GPIO_NUM)
    return;

  intFunc[pin & 0x0F]();
}
