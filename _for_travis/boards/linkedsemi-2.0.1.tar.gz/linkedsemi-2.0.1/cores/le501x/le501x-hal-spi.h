#ifndef MAIN_LE501X_HAL_SPI_H_
#define MAIN_LE501X_HAL_SPI_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "ls_hal_spi_i2s.h"
#include "ls_hal_ssi.h"


/**
  * @brief  Transmit fast an amount of data in blocking mode.
  * @param  hspi pointer to a SPI_HandleTypeDef structure that contains
  *               the configuration information for SPI module.
  * @param  pTxData pointer to data buffer
  * @param  Size amount of data to be sent

  * @retval HAL status
  */
HAL_StatusTypeDef HAL_SPI_Transmit_FAST(SPI_HandleTypeDef *hspi, uint8_t *pTxData, uint16_t Size);


/** \brief SSI Transmit Fast(Polling Mode)
 *  \param[in] hssi Handle of SSI
 *  \param[in] Data Buffer pointer for TX
 *  \param[in] Count Number of data frame in units of ::Data_Frame_Size
 *  \return Status
 */
HAL_StatusTypeDef HAL_SSI_Transmit_FAST(SSI_HandleTypeDef *hssi,void *Data,uint16_t Count);

#ifdef __cplusplus
};
#endif

#endif