#ifndef SDK_CONFIG_H_
#define SDK_CONFIG_H_
#include "app_config.h"
#include "sdk_default_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

