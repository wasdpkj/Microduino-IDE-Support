#ifndef REG_MDM2_H_
#define REG_MDM2_H_
#include "reg_mdm2_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MDM2 ((reg_mdm2_t *)0x40007800)

#ifdef __cplusplus
}
#endif

#endif

