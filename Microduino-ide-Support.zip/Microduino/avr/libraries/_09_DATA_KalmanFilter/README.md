#### Developed by Kristian Lauszus, TKJ Electronics 2012

The code is released under the GNU General Public License.
_________

This is a Kalman filter library for any microcontroller that supports float math.

It can also be used with Arduino, simply copy the folder to your library folder.

My assignment I wrote back in High School regarding Kalman filter can be found here: <http://www.tkjelectronics.dk/uploads/Kalman_SRP.zip>.

For more information see my blog post: <http://blog.tkjelectronics.dk/2012/09/a-practical-approach-to-kalman-filter-and-how-to-implement-it> or send me an email at <kristianl@tkjelectronics.dk>.