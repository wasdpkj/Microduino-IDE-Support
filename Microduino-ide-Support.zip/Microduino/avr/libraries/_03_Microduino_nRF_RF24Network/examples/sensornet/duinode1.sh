jam F_CPU=16000000 "CCFLAGS=-include DuinodeV1.h" -dx UPLOAD_SPEED=115200 u1 && screen /dev/ttyUSB1 57600
