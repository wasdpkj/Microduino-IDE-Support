#!/bin/sh

# Connect u0 to receiver, u1 to sender

jam u0 u1 && expect test.ex 
